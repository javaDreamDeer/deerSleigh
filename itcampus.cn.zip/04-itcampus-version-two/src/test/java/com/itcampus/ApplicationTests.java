package com.itcampus;

import com.github.pagehelper.PageHelper;
import com.itcampus.dao.StatementDao;
import com.itcampus.dao.UserDao;
import com.itcampus.domain.Page;
import com.itcampus.domain.Statement;
import com.itcampus.utils.RegexValidateUtil;
import com.itcampus.utils.SensitiveFilter;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Base64;
import java.util.List;
import java.util.Set;

@SpringBootTest
class ApplicationTests {
    @Resource
    private UserDao userDao = null;

    @Resource
    private StatementDao statementDao = null;

    @Resource
    private SensitiveFilter sensitiveFilter;

    @Resource
    private RedisTemplate redisTemplate;

    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }

    @Test
    void contextLoads() {
    }

    @Test
    void sensitiveFilterTest(){
        String text = "这里可以赌博，可以……吸、毒，哈哈哈";
        text = sensitiveFilter.filter(text);
        System.out.println(text);
    }

    @Test
    void bash64(){
        String password = "b8ca3cbc6fd57c78736c66611a7e7044";
        String encode = Base64.getEncoder().encodeToString(password.getBytes());
        System.out.println(encode);
    }

    @Test
    void redisDockerCompose(){
        String redisKey = "test:count";
        Set keys = redisTemplate.keys("*");
        System.out.println(keys);
    }
}