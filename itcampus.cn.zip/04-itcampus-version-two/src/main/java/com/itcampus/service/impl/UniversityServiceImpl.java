package com.itcampus.service.impl;

import com.itcampus.dao.UniversityDao;
import com.itcampus.service.UniversityService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class UniversityServiceImpl implements UniversityService {

    @Resource
    private UniversityDao universityDao;

    @Override
    public List<String> queryCollegeListDistinct() {
        List<String> collegeList = universityDao.selectCollegeListDistinct();
        return collegeList;
    }

    @Override
    public List<String> queryMajorListByCollege(String college) {
        List<String> majorList = universityDao.selectMajorListByCollege(college);
        return majorList;
    }

    @Override
    public List<Integer> queryGradesListByCollegeMajor(String college, String major) {
        List<Integer> gradesList = universityDao.selectGradesListByCollegeMajor(college, major);
        return gradesList;
    }

    @Override
    public List<String> queryClassesListByCollegeMajorGrades(String college, String major, Integer grades) {
        List<String> classesList = universityDao.selectClassesListByCollegeMajorGrades(college, major,grades);
        return classesList;
    }

    @Override
    public List<String> queryMajorListDistinct() {
        List<String> majorList = universityDao.selectMajorListDistinct();
        return majorList;
    }
}
