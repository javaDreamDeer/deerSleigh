package com.itcampus.service.impl;

import com.github.pagehelper.PageHelper;
import com.itcampus.dao.*;
import com.itcampus.domain.*;
import com.itcampus.service.NoticeService;
import com.itcampus.utils.RedisKeyUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class NoticeServiceImpl implements NoticeService {

    @Resource
    private NoticeDao noticeDao;

    @Resource
    private UserDao userDao;

    @Resource
    private MessageDao messageDao;

    @Resource
    private CommentDao commentDao;

    @Resource
    private StatementDao statementDao;

    @Autowired
    private RedisTemplate redisTemplate;

    public void setNoticeDao(NoticeDao noticeDao) {
        this.noticeDao = noticeDao;
    }

    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }

    public void setMessageDao(MessageDao messageDao) {
        this.messageDao = messageDao;
    }

    public void setCommentDao(CommentDao commentDao) {
        this.commentDao = commentDao;
    }

    public void setStatementDao(StatementDao statementDao) {
        this.statementDao = statementDao;
    }

    @Override
    public Integer increase(Notice notice) {
        Integer num = noticeDao.insert(notice);
        return num;
    }

    @Override
    public Map<String, Object> checkNoticeTotal(Integer idUserTarget) {
        Map<String, Object> map = new HashMap<>();
        List<Notice> noticeList = noticeDao.selectListByIdUserTarget(idUserTarget);
        Integer countComment = 0;
        Integer countPraise = 0;
        Integer countFollow = 0;
        Integer countGoodwill = 0;
        Integer countIllegality = 0;
        map.put("noticeCommentLast", null);
        map.put("userCommentLast", null);
        map.put("noticePraiseLast", null);
        map.put("userPraiseLast", null);
        map.put("noticeFollowLast", null);
        map.put("userFollowLast", null);
        map.put("noticeGoodwillLast", null);
        map.put("userGoodwillLast", null);
        map.put("noticeIllegalityLast", null);
        map.put("userIllegalityLast", null);
        Integer countUnreadComment = 0;
        Integer countUnreadPraise = 0;
        Integer countUnreadFollow = 0;
        Integer countUnreadGoodwill = 0;
        Integer countUnreadIllegality = 0;
        for (Notice notice : noticeList){
            if(("comment".equals(notice.getTypeEvent()) || "reply".equals(notice.getTypeEvent()))){
                countComment ++;
                if("unread".equals(notice.getStatus())){
                    countUnreadComment ++;
                }
                if(map.get("noticeCommentLast") == null){
                    map.put("noticeCommentLast", notice);
                    UserLogined user = userDao.selectUserLoginedById(notice.getIdUser());
                    map.put("userCommentLast", user);
                }
            }else if("praise".equals(notice.getTypeEvent())){
                countPraise ++;
                if("unread".equals(notice.getStatus())){
                    countUnreadPraise ++;
                }
                if(map.get("noticePraiseLast") == null){
                    map.put("noticePraiseLast", notice);
                    UserLogined user = userDao.selectUserLoginedById(notice.getIdUser());
                    map.put("userPraiseLast", user);
                }
            }else if("follow".equals(notice.getTypeEvent())){
                countFollow ++;
                if("unread".equals(notice.getStatus())){
                    countUnreadFollow ++;
                }
                if(map.get("noticeFollowLast") == null){
                    map.put("noticeFollowLast", notice);
                    UserLogined user = userDao.selectUserLoginedById(notice.getIdUser());
                    map.put("userFollowLast", user);
                }
            }else if("goodwill".equals(notice.getTypeEvent())){
                countGoodwill ++;
                if("unread".equals(notice.getStatus())){
                    countUnreadGoodwill ++;
                }
                if(map.get("noticeGoodwillLast") == null){
                    map.put("noticeGoodwillLast", notice);
                    UserLogined user = userDao.selectUserLoginedById(notice.getIdUser());
                    map.put("userGoodwillLast", user);
                }
            } else if("illegality".equals(notice.getTypeEvent())){
                countIllegality ++;
                if("unread".equals(notice.getStatus())){
                    countUnreadIllegality ++;
                }
                if(map.get("noticeIllegalityLast") == null){
                    map.put("noticeIllegalityLast", notice);
                    UserLogined user = userDao.selectUserLoginedById(notice.getIdUser());
                    map.put("userIllegalityLast", user);
                }
            }
        }
        map.put("countComment", countComment);
        map.put("countPraise", countPraise);
        map.put("countFollow", countFollow);
        map.put("countGoodwill", countGoodwill);
        map.put("countIllegality", countIllegality);

        map.put("countUnreadComment", countUnreadComment);
        map.put("countUnreadPraise", countUnreadPraise);
        map.put("countUnreadFollow", countUnreadFollow);
        map.put("countUnreadGoodwill", countUnreadGoodwill);
        map.put("countUnreadIllegality", countUnreadIllegality);

        Integer letterUnreadCountTotal = messageDao.selectLetterUnreadCount(idUserTarget, null);
        map.put("countTotalUnreadLetter", letterUnreadCountTotal);
        Integer noticeUnreadCountTotal = countUnreadComment + countUnreadPraise + countUnreadFollow + countUnreadGoodwill + countUnreadIllegality;
        map.put("countTotalUnreadNotice", noticeUnreadCountTotal);
        return map;
    }

    @Override
    public Integer checkUnreadCount(Integer idUserTarget, String status) {
        Integer count = noticeDao.selectUnreadCount(idUserTarget, "unread");
        return count;
    }

    @Override
    public int checkCountByTypeEvent(Integer idUserTarget, String typeEvent) {
        int count = noticeDao.selectCountByTypeEvent(idUserTarget, typeEvent);
        return count;
    }

    @Override
    public Integer decreaseById(Integer id) {
        Integer num = noticeDao.updateStatusById(id, "deleted");
        return num;
    }

    @Override
    public Map<String, Object> decreaseListByTypeEvent(Integer idUserTarget, String typeEvent) throws SQLException {
        Map<String, Object> map = new HashMap<>();
        List<Integer> idList = noticeDao.selectIdListByIdUserTargetTypeEvent(idUserTarget, typeEvent);
        if(idList.size() != 0){
            Integer num = noticeDao.updateStatusByIdList(idList, "deleted");
            if(num != idList.size()){
                throw new SQLException("清空通知事件失败");
            }
            map.put("success", "success");
        }
        return map;
    }

    @Override
    public Map<String, Object> queryNoticeTypeEvent(Integer idUserTarget, String typeEvent, int pageIndex, int pageSize) throws SQLException {
        Map<String, Object> map = new HashMap<>();
        PageHelper.startPage(pageIndex, pageSize);
        List<Notice> noticeList = noticeDao.selectListByIdUserTargetTypeEvent(idUserTarget, typeEvent);
        List<Map<String, Object>> list = new ArrayList<>();
        List<Integer> idList = new ArrayList<>();
        for (Notice notice : noticeList){
            if("unread".equals(notice.getStatus())){
                idList.add(notice.getId());
            }
            Map<String, Object> mapNotice = new HashMap<>();
            if("comment".equals(notice.getTypeEvent()) ||
                    "reply".equals(notice.getTypeEvent()) ||
                    "praise".equals(notice.getTypeEvent())){
                Comment comment = null;
                int countBefore = 0;
                int pageIndexEntity = 0;
                if("comment".equals(notice.getTypeEvent())){
                    comment = commentDao.selectCommentById(notice.getIdEvent());
                    mapNotice.put("comment", comment);
                } else if("reply".equals(notice.getTypeEvent())){
                    comment = commentDao.selectCommentById(notice.getIdEvent());
                    mapNotice.put("comment", comment);
                    comment = commentDao.selectCommentById(notice.getIdEntity());
                }else if("praise".equals(notice.getTypeEvent())) {
                    if("statement".equals(notice.getTypeEntity())){
                        Statement statement = statementDao.selectStatementById(notice.getIdEntity());
                        mapNotice.put("entity", statement);
                        notice.setUrlEntity("/statement/detail/"+notice.getIdEntity());
                    } else if ("comment".equals(notice.getTypeEntity())) {
                        comment = commentDao.selectCommentById(notice.getIdEntity());
                        mapNotice.put("entity", comment);
                    } else if ("reply".equals(notice.getTypeEntity())) {
                        comment = commentDao.selectCommentById(notice.getIdEntity());
                        mapNotice.put("entity", comment);
                        comment = commentDao.selectCommentById(comment.getIdEntity());
                    }
                }
                /*除了点赞发布贴，统一处理url地址*/
                if(comment != null){
                    countBefore = commentDao.selectCountBeforeByComment(comment);
                    pageIndexEntity = (countBefore % 5 == 0)?(countBefore / 5):(countBefore / 5 + 1);
                    notice.setUrlEntity("/statement/detail/"+comment.getIdEntity()+"?pageIndex="+pageIndexEntity);
                }
            }else if("follow".equals(notice.getTypeEvent())){
                String followerKey = RedisKeyUtil.getFollowerKey("user", notice.getIdUserTarget());
                Double scoreFollower = redisTemplate.opsForZSet().score(followerKey, notice.getIdUser());
                /*redis查询不到数据，说明此时的通知事件是取消关注*/
                if(scoreFollower == null){
                    /*此时直接设置url地址即可*/
                    notice.setUrlEntity("/follow/follower");
                }else{
                    /*我的粉丝列表是倒序，时间戳是递减的，要用zrevrank从大到小排序，而不是zrank()从小到大排序*/
                    long countBefore = redisTemplate.opsForZSet().reverseRank(followerKey, notice.getIdUser());
                    int pageIndexEntity = (int) ((countBefore / 10 == 0)?(countBefore / 10):(countBefore / 10 + 1));
                    notice.setUrlEntity("/follow/follower?pageIndex="+pageIndexEntity);
                }
            }else if("goodwill".equals(notice.getTypeEvent())){
                /*关注用户发布新帖通知，urlEntity已经提前指定好，所以此处不用指定*/
                if("statement".equals(notice.getTypeEntity())){
                    Statement statement = statementDao.selectStatementById(notice.getIdEvent());
                    mapNotice.put("entity", statement);
                }else if("comment".equals(notice.getTypeEntity())){
                    Comment comment = commentDao.selectCommentById(notice.getIdEvent());
                    mapNotice.put("entity", comment);
                }
            }else if("illegality".equals(notice.getTypeEvent())){
                int countBefore = 0;
                int pageIndexEntity = 0;
                if("statement".equals(notice.getTypeEntity())){
                    /*管理员将你的发布贴拉黑，跳转到我的发布*/
                    Statement statement = statementDao.selectStatementById(notice.getIdEvent());
                    mapNotice.put("entity", statement);
                    countBefore = statementDao.selectCountBeforeById(notice.getIdUserTarget(), notice.getIdEvent());
                    pageIndexEntity = (countBefore / 10 == 0)?(countBefore / 10):(countBefore / 10 + 1);
                    notice.setUrlEntity("/profile/statement?pageIndex=" + pageIndexEntity);
                }else if("comment".equals(notice.getTypeEntity())){
                    /*楼主把你的评论拉黑，跳转到我的评论*/
                    Comment comment = commentDao.selectCommentById(notice.getIdEvent());
                    mapNotice.put("entity", comment);
                    countBefore = commentDao.selectCountBeforeById(notice.getIdUserTarget(), notice.getIdEvent());
                    pageIndexEntity = (countBefore / 10 == 0)?(countBefore / 10):(countBefore / 10 + 1);
                    notice.setUrlEntity("/profile/comment?pageIndex=" + pageIndexEntity);
                }
            }
            mapNotice.put("notice", notice);
            UserLogined user = userDao.selectUserLoginedById(notice.getIdUser());
            mapNotice.put("user", user);
            list.add(mapNotice);
        }
        /*修改未读状态*/
        if(idList.size() != 0){
            Integer num = noticeDao.updateStatusByIdList(idList, "read");
            if(num != idList.size()){
                throw new SQLException("修改通知事件失败，修改数量错误");
            }
        }
        map.put("noticeList", list);
        return map;
    }
}
