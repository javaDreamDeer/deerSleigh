package com.itcampus.service;

import com.itcampus.domain.Message;

import java.sql.SQLException;
import java.util.Map;

public interface MessageService {
    int checkConversationCount(Integer idUser);

    Map<String, Object> queryConversationList(Integer idUser, int pageIndex, int pageSize);

    int checkLetterCount(String idConversation);

    Map<String, Object> queryLetterList(Integer idUser, String idConversation, int pageIndex, int pageSize) throws SQLException;

    Integer increaseLetter(Message message);

    Integer checkLetterUnreadCount(Integer id);

    Message checkById(Integer id);

    Integer decreaseById(Integer id);
}
