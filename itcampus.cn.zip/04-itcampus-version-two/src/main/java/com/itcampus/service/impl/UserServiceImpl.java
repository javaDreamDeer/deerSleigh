package com.itcampus.service.impl;

import com.itcampus.dao.TicketLoginDao;
import com.itcampus.dao.UniversityDao;
import com.itcampus.dao.UserDao;
import com.itcampus.domain.TicketLogin;
import com.itcampus.domain.University;
import com.itcampus.domain.User;
import com.itcampus.domain.UserLogined;
import com.itcampus.service.UserService;
import com.itcampus.utils.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import javax.annotation.Resource;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.TimeUnit;

@Service
public class UserServiceImpl implements UserService {
    @Resource
    private UserDao userDao;

    @Resource
    private TicketLoginDao ticketLoginDao;

    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }

    public void setTicketLoginDao(TicketLoginDao ticketLoginDao) {
        this.ticketLoginDao = ticketLoginDao;
    }

    @Resource
    UniversityDao universityDao;

    @Autowired
    private RedisTemplate redisTemplate;

    @Autowired
    private MailClient mailClient;

    @Autowired
    private TemplateEngine templateEngine;

    @Value("${itcampus.com}")
    private String domainName;

    @Value("${server.servlet.context-path}")
    private String contextPath;

    @Override
    public User checkUserById(Integer id) {
        User user = getUserCache(id);
        if (user == null) {
            user = initUserCache(id);
        }
        return user;
    }

    /*
    * 这是一个事务*/
    @Transactional
    @Override
    public Map<String, Object> register(User user) throws IllegalAccessException, SQLException {
        /*参数不为空*/
        Map<String, Object> map = new HashMap<>();
        User userTest = userDao.selectUserByUsername(user.getUsername());
        if(userTest != null){
            map.put("usernameMsg", "该用户名已被注册！");
            return map;
        }
        userTest = userDao.selectUserByEmail(user.getEmail());
        if(userTest != null){
            map.put("emailMsg", "该邮箱已被注册！");
            return map;
        }
        /*参数正常*/
        user.setRandom(SecurityUtil.generateUUID());
        user.setPassword(SecurityUtil.encryptMD5(user.getPassword() + user.getRandom()));
        user.setCodeActivate(SecurityUtil.generateUUID());
        user.setStatus("down");
        user.setIdentity("member");
        user.setConditions("health");
        user.setTimeCreate(new Date());
        user.setNameTrueUse("no");
        user.setUrlHeader(String.format("http://images.nowcoder.com/head/%dt.png", new Random().nextInt(1000)));
        Integer num = userDao.insertUser(user);
        if(num != 1){
            throw new SQLException("插入注册用户数据失败");
        }
        /*发送激活邮件*/
        Context context = new Context();
        context.setVariable("email", user.getEmail());
        String urlActivate = domainName + contextPath + "/activate/" + user.getId() + "/" + user.getCodeActivate();
        context.setVariable("urlActivate", urlActivate);
        String content = templateEngine.process("mail/activation", context);
        mailClient.sendMail(user.getEmail(), "IT校园账号激活链接", content);
        map.put("success", "success");
        return map;
    }

    @Override
    public User checkUserByIdCodeActivate(Integer id, String codeActivate) {
        User user = userDao.selectUserByIdCodeActivate(id, codeActivate);
        return user;
    }

    @Override
    public Integer reviseStatusById(Integer id, String status) {
        Integer num = userDao.updateStatusById(id, status);
        /*用户内容更新，清除Redis缓存用户*/
        clearUserCache(id);
        return num;
    }

    /*事务*/
    @Transactional
    @Override
    public Map<String, Object> login(String username, String password, int daysExpired) throws IllegalAccessException, SQLException {
        /*参数不为空*/
        /*判断username是用户名还是邮箱*/
        User userTest = null;
        boolean flag = RegexValidateUtil.validateEmail(username);
        if(!flag){
            userTest = userDao.selectUserByUsername(username);
        }else{
            userTest = userDao.selectUserByEmail(username);
        }
        Map<String, Object> map = new HashMap<>();
        /*检查信息*/
        if(userTest == null){
            map.put("usernameMsg", "用户名或邮箱不存在！");
            return map;
        }else{
            /*查看用户是否有登录权限*/
            if("danger".equals(userTest.getConditions())){
                map.put("alterError", "您当前的账号为危险状态！不能登录！");
                return map;
            }
            /*检查用户的账号是否已经激活*/
            if("down".equals(userTest.getStatus())){
                map.put("alterWarning", "您当前的账号尚未激活，不能登录！");
                return map;
            }
            String passwordEncrypt = SecurityUtil.encryptMD5(password + userTest.getRandom());
            if(!userTest.getPassword().equals(passwordEncrypt)){
                map.put("passwordMsg", "密码错误!");
                return map;
            }else{
                /*信息正确*/
                String ticket = SecurityUtil.generateUUID();
                TicketLogin ticketLogin = new TicketLogin(null, userTest.getUsername(), ticket, "up", DateUtils.addDays(new Date(), daysExpired));
                Integer num = ticketLoginDao.insertTicketLogin(ticketLogin);
                if(num != 1){
                    throw new SQLException("登录凭证插入失败");
                }
                num = -1;
                num = ticketLoginDao.updateStatusByIdUsername(ticketLogin.getId(), ticketLogin.getUsername(), "down");
                if(num == -1){
                    throw new SQLException("新的登录凭证插入后，旧的登录凭证更新失败");
                }
                map.put("username", userTest.getUsername());
                map.put("ticket", ticket);
                map.put("success", "success");
                return map;
            }
        }
    }

    @Override
    public TicketLogin checkTicketLoginByUsernameTicketStatus(String username, String ticket, String status) {
        TicketLogin ticketLogin = ticketLoginDao.selectByUsernameTicketStatus(username, ticket, status);
        return ticketLogin;
    }

    @Override
    public UserLogined checkUserLoginedByUsername(String username) {
        UserLogined userLogined = userDao.selectUserLoginedByUsername(username);
        return userLogined;
    }

    @Override
    public Integer reviseStatusTicketLoginById(Integer id, String status) {
        Integer num = ticketLoginDao.updateStatusById(id, status);
        return num;
    }

    @Override
    public Map<String, Object> logout(String username, String ticket) throws SQLException {
        Map<String, Object> map = new HashMap<>();
        TicketLogin ticketLogin = ticketLoginDao.selectByUsernameTicketStatus(username, ticket, "up");
        if(ticketLogin == null){
            map.put("logoutMsg", "您的登录凭证非正常失效！");
            map.put("success", "success");
        }else{
            Integer num = ticketLoginDao.updateStatusById(ticketLogin.getId(), "down");
            if(num != 1){
                throw new SQLException("登出过程中，销毁凭证失败");
            }
            map.put("success", "success");
        }
        return map;
    }

    @Override
    public Integer reviseUrlHeaderByUsername(Integer id, String urlHeader) {
        Integer num = userDao.updateUrlHeaderById(id, urlHeader);
        /*用户内容更新，清除Redis缓存用户*/
        clearUserCache(id);
        return num;
    }

    /*这是一个事务*/
    @Transactional
    @Override
    public Map<String, Object> revisePassword(Integer id, String passwordOld, String passwordNew) throws IllegalAccessException, SQLException {
        Map<String, Object> map = new HashMap<>();
        User userTest = userDao.selectUserById(id);
        if(userTest == null){
            throw new IllegalAccessException("非法访问，当前线程获取的用户不存在");
        }
        String passwordOldEncrypt = SecurityUtil.encryptMD5(passwordOld + userTest.getRandom());
        if(!userTest.getPassword().equals(passwordOldEncrypt)){
            map.put("passwordOldMsg", "原密码错误！");
            return map;
        }
        /*参数正确*/
        /*检查用户是否登录到期*/
        TicketLogin ticketLogin = ticketLoginDao.selectByUsernameStatus(userTest.getUsername(), "up");
        if(ticketLogin != null){
            String random = SecurityUtil.generateUUID();
            String passwordNewEncrypt = SecurityUtil.encryptMD5(passwordNew + random);
            Integer num = userDao.updatePasswordById(userTest.getId(), passwordNewEncrypt, random);
            if(num != 1){
                throw new SQLException("修改密码失败");
            }
            /*修改成功，要求用户重新登录*/
            num = ticketLoginDao.updateStatusById(ticketLogin.getId(), "down");
            if(num != 1){
                throw new SQLException("修改密码后，销毁用户的登录凭证失败");
            }
            map.put("success", "success");
        }else{
            map.put("alterError", "您的登录已失效，修改密码失败，请用原密码重新登录！");
        }
        /*用户内容更新，清除Redis缓存用户*/
        clearUserCache(id);
        return map;
    }

    @Override
    public Map<String, Object> reviseInformation(UserLogined userLogined) throws IllegalAccessException, SQLException {
        Map<String, Object> map = new HashMap<>();
        User user = userDao.selectUserById(userLogined.getId());
        if(user == null){
            throw new IllegalAccessException("非法访问，当前线程获取的用户不存在");
        }
        University university = new University();
        university.setCollege(userLogined.getCollege());
        university.setMajor(userLogined.getMajor());
        university.setGrades(userLogined.getGrades());
        university.setClasses(userLogined.getClasses());
        University universityTest = universityDao.selectByUniversity(university);
        if(universityTest == null){
            map.put("alterWarning", "信息不真实！");
            return map;
        }else{
            /*判断用户是否登录有效*/
            TicketLogin ticketLogin = ticketLoginDao.selectByUsernameStatus(userLogined.getUsername(), "up");
            if(ticketLogin == null){
                map.put("alterError", "您的登录已失效，保存信息失败，请重新登录");
                return map;
            }else{
                /*登录有效*/
                Integer num = userDao.updateCollegeMajorGradesClassesNameTrueById(userLogined);
                if(num != 1){
                    throw new SQLException("修改用户真实信息失败");
                }
                map.put("success", "success");
                /*用户内容更新，清除Redis缓存用户*/
                clearUserCache(userLogined.getId());
                return map;
            }
        }
    }

    @Override
    public UserLogined checkUserLoginedById(Integer id) {
        User user = getUserCache(id);
        if (user == null) {
            user = initUserCache(id);
        }
        UserLogined userLogined = new UserLogined(user.getId(),user.getUsername(),
                user.getEmail(),user.getUrlHeader(),user.getIdentity(),
                user.getConditions(),user.getTimeCreate(),user.getCollege(),
                user.getMajor(), user.getGrades(),user.getClasses(),
                user.getNameTrue(), user.getNameTrueUse());
        return userLogined;
    }

    @Override
    public User checkUserByUsername(String username) {
        User user = userDao.selectUserByUsername(username);
        return user;
    }

    @Override
    public Integer revisePasswordByEmail(String email, String password, String random) {
        User user = userDao.selectUserByEmail(email);
        Integer num = userDao.updatePasswordById(user.getId(), password, random);
        /*用户内容更新，清除Redis缓存用户*/
        clearUserCache(user.getId());
        return num;
    }

    @Override
    public User checkUserByEmail(String email) {
        User user = userDao.selectUserByEmail(email);
        return user;
    }

    @Override
    public Map<String, Object> sendCaptchaEmail(String email) {
        Map<String, Object> map = new HashMap<>();
        Context context = new Context();
        context.setVariable("email", email);
        /*邮箱验证码取6位即可*/
        String captchaEmail = SecurityUtil.generateUUID().substring(0, 6);
        /*将邮箱验证码存入Redis中，生产时间为10分钟*/
        String captchaEmailKey = RedisKeyUtil.getCaptchaEmailKey(email);
        redisTemplate.opsForValue().set(captchaEmailKey, captchaEmail, 600, TimeUnit.SECONDS);
        context.setVariable("captchaEmail", captchaEmail);
        String content = templateEngine.process("mail/forget", context);
        mailClient.sendMail(email, "IT校园找回密码", content);
        map.put("success", "success");
        return map;
    }

    // 1.优先从缓存中取值
    private User getUserCache(int userId) {
        String userKey = RedisKeyUtil.getUserKey(userId);
        return (User) redisTemplate.opsForValue().get(userKey);
    }

    // 2.取不到时初始化缓存数据
    private User initUserCache(int userId) {
        User user = userDao.selectUserById(userId);
        String userKey = RedisKeyUtil.getUserKey(userId);
        /*用户信息缓存一个小时*/
        redisTemplate.opsForValue().set(userKey, user, 3600, TimeUnit.SECONDS);
        return user;
    }

    // 3.数据变更时清除缓存数据
    private void clearUserCache(int userId) {
        String userKey = RedisKeyUtil.getUserKey(userId);
        redisTemplate.delete(userKey);
    }

}
