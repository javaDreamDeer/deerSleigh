package com.itcampus.service;

import java.util.List;
import java.util.Map;

public interface FollowService {
    Map<String, Object> follow(Integer idUser, String typeEntity, Integer idEntity);
    /*查询关注个数*/
    long checkCountFollowee(Integer idUser, String typeEntity);
    /*查询粉丝个数*/
    long checkCountFollower(String typeEntity, Integer idEntity);

    String checkStatusFollowed(Integer idUser, String typeEntity, Integer idEntity);
    /*获取关注用户列表*/
    List<Map<String, Object>> queryFollowee(Integer idUserCurrent, Integer idUser, int dataBegin, int pageSize);
    /*获取粉丝用户列表*/
    List<Map<String, Object>> queryFollower(Integer idUserCurrent, Integer idUser, int dataBegin, int pageSize);
}
