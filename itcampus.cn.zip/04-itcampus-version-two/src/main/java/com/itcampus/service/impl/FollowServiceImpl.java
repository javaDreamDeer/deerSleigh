package com.itcampus.service.impl;

import com.itcampus.dao.UserDao;
import com.itcampus.domain.User;
import com.itcampus.domain.UserLogined;
import com.itcampus.service.FollowService;
import com.itcampus.utils.RedisKeyUtil;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.SessionCallback;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;

@Service
public class FollowServiceImpl implements FollowService {

    @Resource
    private RedisTemplate redisTemplate;

    @Resource
    private UserDao userDao;

    @Override
    public Map<String, Object> follow(Integer idUser, String typeEntity, Integer idEntity) {
        Map<String, Object> map = new HashMap<>();
        redisTemplate.execute(new SessionCallback() {
            @Override
            public Object execute(RedisOperations operations) throws DataAccessException {
                String followeeKey = RedisKeyUtil.getFolloweeKey(idUser, typeEntity);
                String followerKey = RedisKeyUtil.getFollowerKey(typeEntity, idEntity);
                Double scoreFollowee = operations.opsForZSet().score(followeeKey, idEntity);
                Double scoreFollower = operations.opsForZSet().score(followerKey, idUser);
                operations.multi();
                /*ZSet中的元素分数为空说明元素不存在，则关注成功，反之取消关注成功*/
                if(scoreFollowee == null && scoreFollower == null){
                    operations.opsForZSet().add(followeeKey, idEntity, System.currentTimeMillis());
                    operations.opsForZSet().add(followerKey, idUser, System.currentTimeMillis());
                    map.put("statusFollow", "已关注");
                }else{
                    operations.opsForZSet().remove(followeeKey, idEntity);
                    operations.opsForZSet().remove(followerKey, idUser);
                    map.put("statusFollow", "关注TA");
                }
                return operations.exec();
            }
        });
        /*Redis事务外部做查询才有效*/
        /*添加关注后，查看有没有互粉*/
        if("已关注".equals(map.get("statusFollow"))){
            String followerKeySelf = RedisKeyUtil.getFollowerKey("user", idUser);
            Double score = redisTemplate.opsForZSet().score(followerKeySelf, idEntity);
            if(score != null){
                map.put("statusFollow", "已互粉");
            }
        }
        return map;
    }

    @Override
    public long checkCountFollowee(Integer idUser, String typeEntity) {
        String followeeKey = RedisKeyUtil.getFolloweeKey(idUser, typeEntity);
        return redisTemplate.opsForZSet().zCard(followeeKey);
    }

    @Override
    public long checkCountFollower(String typeEntity, Integer idEntity) {
        String followerKey = RedisKeyUtil.getFollowerKey(typeEntity, idEntity);
        return redisTemplate.opsForZSet().zCard(followerKey);
    }

    /*个人主页的时候查询当前用户是否关注主页用户，适用于关注列表或粉丝列表判断*/
    @Override
    public String checkStatusFollowed(Integer idUser, String typeEntity, Integer idEntity) {
        String followeeKeySelf = RedisKeyUtil.getFolloweeKey(idUser, typeEntity);
        Double score = redisTemplate.opsForZSet().score(followeeKeySelf, idEntity);
        if(score != null){
            /*查看我的粉丝里有没有TA*/
            String followerKeySelf = RedisKeyUtil.getFollowerKey(typeEntity, idUser);
            score = redisTemplate.opsForZSet().score(followerKeySelf, idEntity);
            if(score != null){
                return "已互粉";
            }else{
                return "已关注";
            }
        }else{
            return "关注TA";
        }
    }

    /*关注列表*/
    @Override
    public List<Map<String, Object>> queryFollowee(Integer idUserCurrent, Integer idUser, int dataBegin, int pageSize) {
        String followeeKey = RedisKeyUtil.getFolloweeKey(idUser, "user");
        Set<Integer> idTargetSet = redisTemplate.opsForZSet().reverseRange(followeeKey, dataBegin, dataBegin + pageSize - 1);
        if (idTargetSet == null) {
            return null;
        }
        List<Map<String, Object>> list = new ArrayList<>();
        for (Integer idTarget : idTargetSet) {
            Map<String, Object> map = new HashMap<>();
            UserLogined user = userDao.selectUserLoginedById(idTarget);
            map.put("user", user);
            /*用户未登录，什么情况都是未关注状态，前端显示“关注”*/
            if(idUserCurrent == null){
                map.put("statusFollow", "关注TA");
            }else{
                /*即使是当前用户自己访问，也要查询关注状态，因为可能出现互粉情况*/
                /*如果用户访问自己*/
                if(idUserCurrent.equals(idUser)){
                    /*我已经关注了TA，要查看TA是否也关注了我，也就是查看我的粉丝里面有没有TA*/
                    String followerKeySelf = RedisKeyUtil.getFollowerKey("user", idUserCurrent);
                    Double score = redisTemplate.opsForZSet().score(followerKeySelf, idTarget);
                    if(score != null){
                        map.put("statusFollow", "已互粉");
                    }else{
                        map.put("statusFollow", "已关注");
                    }
                }else{
                    /*查看我是否关注了TA，也要查看TA是否也关注了我(即是我的粉丝里有没有TA)*/
                    String status = this.checkStatusFollowed(idUserCurrent, "user", idTarget);
                    map.put("statusFollow", status);
                }
            }
            Double score = redisTemplate.opsForZSet().score(followeeKey, idTarget);
            map.put("timeFollow", new Date(score.longValue()));
            list.add(map);
        }
        return list;
    }

    /*粉丝列表*/
    @Override
    public List<Map<String, Object>> queryFollower(Integer idUserCurrent, Integer idUser, int dataBegin, int pageSize) {
        String followerKey = RedisKeyUtil.getFollowerKey("user", idUser);
        Set<Integer> idTargetSet = redisTemplate.opsForZSet().reverseRange(followerKey, dataBegin, dataBegin + pageSize - 1);
        if (idTargetSet == null) {
            return null;
        }
        List<Map<String, Object>> list = new ArrayList<>();
        for (Integer idTarget : idTargetSet) {
            Map<String, Object> map = new HashMap<>();
            UserLogined user = userDao.selectUserLoginedById(idTarget);
            map.put("user", user);
            /*用户未登录，什么情况都是未关注状态，前端显示“关注”*/
            if(idUserCurrent == null){
                map.put("statusFollow", "关注TA");
            }else{
                /*即使是当前用户自己访问，也要查询关注状态，因为可能出现互粉情况*/
                /*如果用户访问自己*/
                if(idUserCurrent.equals(idUser)){
                    /*TA已近是我的粉丝，查看我是否关注了TA*/
                    String followeeKeySelf = RedisKeyUtil.getFolloweeKey(idUserCurrent, "user");
                    Double score = redisTemplate.opsForZSet().score(followeeKeySelf, idTarget);
                    if(score != null){
                        map.put("statusFollow", "已互粉");
                    }else{
                        map.put("statusFollow", "关注TA");
                    }
                }else{
                    /*查看我是否关注了TA，也要查看TA是不是我的粉丝*/
                    String status = this.checkStatusFollowed(idUserCurrent, "user", idTarget);
                    map.put("statusFollow", status);
                }
            }
            Double score = redisTemplate.opsForZSet().score(followerKey, idTarget);
            map.put("timeFollow", new Date(score.longValue()));
            list.add(map);
        }
        return list;
    }
}
