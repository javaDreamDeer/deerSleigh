package com.itcampus.service;

import com.itcampus.domain.Notice;

import java.sql.SQLException;
import java.util.Map;

public interface NoticeService {

    Integer increase(Notice notice);

    Map<String, Object> checkNoticeTotal(Integer idUserTarget);

    Integer checkUnreadCount(Integer idUserTarget, String status);

    Map<String, Object> queryNoticeTypeEvent(Integer idUserTarget, String typeEvent, int pageIndex, int pageSize) throws SQLException;

    int checkCountByTypeEvent(Integer idUserTarget, String typeEvent);

    Integer decreaseById(Integer id);

    Map<String, Object> decreaseListByTypeEvent(Integer idUserTarget, String typeEvent) throws SQLException;
}
