package com.itcampus.service;

import java.util.Map;

public interface PraiseService {
    Map<String, Object> increaseOrDecreasePraise(Integer idUser, String typeEntity, Integer idEntity, Integer idUserEntity);
    long checkCountPraiseEntity(String typeEntity, Integer idEntity);
    boolean checkStatusPraiseEntity(Integer idUser, String typeEntity, Integer idEntity);
    Integer checkCountPraiseUser(Integer idUser);
}
