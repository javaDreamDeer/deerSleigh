package com.itcampus.service.impl;

import com.github.pagehelper.PageHelper;
import com.itcampus.dao.MessageDao;
import com.itcampus.dao.NoticeDao;
import com.itcampus.dao.UserDao;
import com.itcampus.domain.Message;
import com.itcampus.domain.User;
import com.itcampus.domain.UserLogined;
import com.itcampus.service.MessageService;
import com.itcampus.service.UserService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class MessageServiceImpl implements MessageService {

    @Resource
    private MessageDao messageDao;

    @Resource
    private UserDao userDao;

    @Resource
    private NoticeDao noticeDao;

    public void setMessageDao(MessageDao messageDao) {
        this.messageDao = messageDao;
    }

    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }

    public void setNoticeDao(NoticeDao noticeDao) {
        this.noticeDao = noticeDao;
    }

    @Override
    public int checkConversationCount(Integer idUser) {
        int count = messageDao.selectConversationCount(idUser);
        return count;
    }

    @Override
    public Map<String, Object> queryConversationList(Integer idUser, int pageIndex, int pageSize) {
        Map<String, Object> map = new HashMap<>();
        PageHelper.startPage(pageIndex, pageSize);
        List<Message> messageList = messageDao.selectConversationList(idUser);
        List<Map<String, Object>> listConversation = new ArrayList<>();
        for(Message message : messageList){
            Map<String, Object> mapConversation = new HashMap<>();
            mapConversation.put("infoConversation", message);
            UserLogined userLogined = null;
            if(idUser.equals(message.getIdSender())){
                userLogined = userDao.selectUserLoginedById(message.getIdReceiver());
            }else{
                userLogined = userDao.selectUserLoginedById(message.getIdSender());
            }
            if(userLogined != null){
                mapConversation.put("userConversation", userLogined);
            }
            Integer letterCount = messageDao.selectLetterCount(message.getIdConversation());
            mapConversation.put("countLetter", letterCount);
            Integer letterUnreadCount = messageDao.selectLetterUnreadCount(idUser, message.getIdConversation());
            mapConversation.put("countUnreadLetter", letterUnreadCount);
            listConversation.add(mapConversation);
        }
        map.put("listConversation", listConversation);
        Integer letterUnreadCountTotal = this.checkLetterUnreadCount(idUser);
        map.put("countTotalUnreadLetter", letterUnreadCountTotal);
        Integer noticeUnreadCountTotal = noticeDao.selectUnreadCount(idUser, "unread");
        map.put("countTotalUnreadNotice", noticeUnreadCountTotal);
        return map;
    }

    @Override
    public int checkLetterCount(String idConversation) {
        int count = messageDao.selectLetterCount(idConversation);
        return count;
    }

    @Override
    public Map<String, Object> queryLetterList(Integer idUser, String idConversation, int pageIndex, int pageSize) throws SQLException {
        Map<String, Object> map = new HashMap<>();
        PageHelper.startPage(pageIndex, pageSize);
        List<Message> messageList = messageDao.selectLetterList(idConversation);
        List<Map<String, Object>> listLetter = new ArrayList<>();
        List<Integer> unreadIdList = new ArrayList<>();
        for(Message message : messageList){
            /*判断接收者未读*/
            if("unread".equals(message.getStatus()) && idUser.equals(message.getIdReceiver())){
                unreadIdList.add(message.getId());
            }
            Map<String, Object> mapLetter = new HashMap<>();
            mapLetter.put("infoLetter", message);
            UserLogined userLogined = userDao.selectUserLoginedById(message.getIdSender());
            mapLetter.put("userLetter", userLogined);
            listLetter.add(mapLetter);
        }
        /*取消所有未读*/
        if(unreadIdList.size() != 0){
            Integer num = messageDao.updateStatusByIdList(unreadIdList, "read");
            if(num != unreadIdList.size()){
                throw new SQLException("修改私信的未读状态失败，修改数量错误");
            }
        }
        map.put("listLetter", listLetter);
        UserLogined userLoginedOther = null;
        String[] ids = idConversation.split("_");
        Integer idHis = Integer.parseInt(ids[0]);
        Integer idHer = Integer.parseInt(ids[1]);
        if(idUser.equals(idHis)){
            userLoginedOther = userDao.selectUserLoginedById(idHer);
        }else{
            userLoginedOther = userDao.selectUserLoginedById(idHis);
        }
        map.put("userLetterOther", userLoginedOther);
        return map;
    }

    @Override
    public Integer increaseLetter(Message message) {
        Integer num = messageDao.insertLetter(message);
        return num;
    }

    @Override
    public Integer checkLetterUnreadCount(Integer id) {
        Integer letterUnreadCountTotal = messageDao.selectLetterUnreadCount(id, null);
        return letterUnreadCountTotal;
    }

    @Override
    public Message checkById(Integer id) {
        Message message = messageDao.selectById(id);
        return message;
    }

    @Override
    public Integer decreaseById(Integer id) {
        Integer num = messageDao.updateStatusByIdStatus(id, "deleted");
        return num;
    }
}
