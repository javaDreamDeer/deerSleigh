package com.itcampus.service;

import com.itcampus.domain.Statement;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public interface StatementService {
    List<Statement> queryStatementList(Integer pageIndex, Integer pageSize);

    Integer checkStatementCount();

    Map<String, Object> increaseStatement(Statement statement) throws IllegalAccessException, SQLException;

    Map<String, Object> checkStatementById(Integer idUserCurrent, Integer id, int pageIndex, int pageSize, int dataRows) throws SQLException;

    int checkCountByIdUser(Integer idUser);

    Map<String, Object> queryByIdUser(Integer idUser, int pageIndex, int pageSize);

    Statement checkById(Integer id);

    Integer reviseStatusById(Integer id, String status);

    Integer reviseTypeById(Integer id, String type);
}
