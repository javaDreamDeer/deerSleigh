package com.itcampus.service;

import com.itcampus.domain.Comment;

import java.sql.SQLException;
import java.util.Map;

public interface CommentService {
    int checkCommentCountByIdEntityTypeEntity(Integer idEntity, String typeEntity);

    Map<String, Object> increaseComment(Comment comment) throws SQLException, IllegalAccessException;

    int checkCountByIdUser(Integer idUser);

    Map<String, Object> queryByIdUser(Integer idUser, int pageIndex, int pageSize);

    Comment checkById(Integer id);

    Integer reviseStatusById(Integer id, String status);
}
