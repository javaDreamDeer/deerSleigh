package com.itcampus.service;

import java.util.List;

public interface UniversityService {

    List<String> queryCollegeListDistinct();

    List<String> queryMajorListByCollege(String college);

    List<Integer> queryGradesListByCollegeMajor(String college, String major);

    List<String> queryClassesListByCollegeMajorGrades(String college, String major, Integer grades);

    List<String> queryMajorListDistinct();
}
