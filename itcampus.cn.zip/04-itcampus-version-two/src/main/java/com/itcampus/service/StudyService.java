package com.itcampus.service;

import com.itcampus.domain.Study;

import java.util.List;

public interface StudyService {
    List<Study> queryList();
}
