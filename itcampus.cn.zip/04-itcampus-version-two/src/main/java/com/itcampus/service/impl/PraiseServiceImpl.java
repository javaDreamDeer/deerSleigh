package com.itcampus.service.impl;

import com.itcampus.service.PraiseService;
import com.itcampus.utils.RedisKeyUtil;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.SessionCallback;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

@Service
public class PraiseServiceImpl implements PraiseService {

    @Resource
    private RedisTemplate redisTemplate;

    @Override
    public Map<String, Object> increaseOrDecreasePraise(Integer idUser, String typeEntity, Integer idEntity, Integer idUserEntity) {
        Map<String, Object> map = new HashMap<>();
        String praiseKeyEntity = RedisKeyUtil.getPraiseKeyEntity(typeEntity, idEntity);
        String praiseKeyUser = RedisKeyUtil.getPraiseKeyUser(idUserEntity);
        redisTemplate.execute(new SessionCallback() {
            @Override
            public Object execute(RedisOperations operations) throws DataAccessException {
                boolean isMember = operations.opsForSet().isMember(praiseKeyEntity, idUser);
                /*开启事务*/
                operations.multi();
                if (isMember) {
                    operations.opsForSet().remove(praiseKeyEntity, idUser);
                    operations.opsForValue().decrement(praiseKeyUser);
                    map.put("statusPraise", "赞");
                } else {
                    operations.opsForSet().add(praiseKeyEntity, idUser);
                    operations.opsForValue().increment(praiseKeyUser);
                    map.put("statusPraise", "已赞");
                }
                /*提交事务*/
                return operations.exec();
            }
        });
        map.put("countPraise", redisTemplate.opsForSet().size(praiseKeyEntity));
        return map;
    }

    @Override
    public long checkCountPraiseEntity(String typeEntity, Integer idEntity) {
        String praiseKeyEntity = RedisKeyUtil.getPraiseKeyEntity(typeEntity, idEntity);
        return redisTemplate.opsForSet().size(praiseKeyEntity);
    }

    @Override
    public boolean checkStatusPraiseEntity(Integer idUser, String typeEntity, Integer idEntity) {
        String praiseKeyEntity = RedisKeyUtil.getPraiseKeyEntity(typeEntity, idEntity);
        return redisTemplate.opsForSet().isMember(praiseKeyEntity, idUser);
    }

    @Override
    public Integer checkCountPraiseUser(Integer idUser) {
        String praiseKeyUser = RedisKeyUtil.getPraiseKeyUser(idUser);
        Integer count = (Integer) redisTemplate.opsForValue().get(praiseKeyUser);
        return count == null ? 0 : count;
    }
}
