package com.itcampus.service.impl;

import com.github.pagehelper.PageHelper;
import com.itcampus.dao.CommentDao;
import com.itcampus.dao.StatementDao;
import com.itcampus.dao.UserDao;
import com.itcampus.domain.Comment;
import com.itcampus.domain.Statement;
import com.itcampus.domain.User;
import com.itcampus.domain.UserLogined;
import com.itcampus.service.PraiseService;
import com.itcampus.service.StatementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.sql.SQLException;
import java.util.*;

@Service
public class StatementServiceImpl implements StatementService {

    @Resource
    private StatementDao statementDao;

    @Resource
    private UserDao userDao;

    @Resource
    private CommentDao commentDao;

    @Autowired
    private PraiseService praiseService;

    public void setStatementDao(StatementDao statementDao) {
        this.statementDao = statementDao;
    }

    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }

    public void setCommentDao(CommentDao commentDao) {
        this.commentDao = commentDao;
    }

    @Override
    public List<Statement> queryStatementList(Integer pageIndex, Integer pageSize) {
        PageHelper.startPage(pageIndex, pageSize);
        List<Statement> statementList = statementDao.selectStatementList();
        return statementList;
    }

    @Override
    public Integer checkStatementCount() {
        Integer count = statementDao.selectStatementCount();
        return count;
    }

    @Override
    public Map<String, Object> increaseStatement(Statement statement) throws SQLException {
        Map<String, Object> map = new HashMap<>();
        Integer num = statementDao.insertStatement(statement);
        if(num != 1){
            throw new SQLException("发布插入失败");
        }
        map.put("success", "success");
        return map;
    }

    @Override
    public Map<String, Object> checkStatementById(Integer idUserCurrent, Integer id, int pageIndex, int pageSize, int dataRows) throws SQLException {
        Map<String, Object> map = new HashMap<>();
        Statement statement = statementDao.selectStatementById(id);
        if(statement != null){
            /*重新查询帖子的评论数并更新*/
            if(dataRows != statement.getCountComment()){
                statement.setCountComment(dataRows);
                Integer num = statementDao.updateCountCommentById(statement.getId(), dataRows);
                if(num != 1){
                    throw new SQLException("修改发布帖子评论数失败");
                }
            }
            long countPraise = praiseService.checkCountPraiseEntity("statement", statement.getId());
            statement.setCountPraise((int) countPraise);
            map.put("statement", statement);
            /*查看当前用户是否点赞发布
            * 如果用户未登录，将不提供点赞功能*/
            if(idUserCurrent != null){
                boolean statusPraise = praiseService.checkStatusPraiseEntity(idUserCurrent, "statement", statement.getId());
                map.put("statusPraiseStatement", statusPraise);
                map.put("userStatusLogined", true);
            }else{
                map.put("userStatusLogined", false);
            }
            Integer idUser = statement.getIdUser();
            UserLogined userLogined = userDao.selectUserLoginedById(idUser);
            if(userLogined != null){
                map.put("user", userLogined);
            }
            /*查询帖子列表*/
            List<Map<String, Object>> listDiscussion = new ArrayList<>();
            List<Map<String, Object>> listDiscussionOfficial = new ArrayList<>();
            PageHelper.startPage(pageIndex, pageSize);
            List<Comment> commentList = commentDao.selectCommentListByIdEntityTypeEntity(statement.getId(), "comment");
            for(Comment comment : commentList){
                Map<String, Object> mapComment = new HashMap<>();
                mapComment.put("infoComment", comment);
                countPraise = praiseService.checkCountPraiseEntity("comment", comment.getId());
                mapComment.put("countPraiseComment", countPraise);
                if(idUserCurrent != null){
                    boolean statusPraise = praiseService.checkStatusPraiseEntity(idUserCurrent, "comment", comment.getId());
                    mapComment.put("statusPraiseComment", statusPraise);
                }
                UserLogined userComment = userDao.selectUserLoginedById(comment.getIdUser());
                mapComment.put("userComment", userComment);
                /*replyList不需要分页*/
                List<Comment> replyList = commentDao.selectCommentListByIdEntityTypeEntity(comment.getId(), "reply");
                mapComment.put("countReply", replyList.size());
                List<Map<String, Object>> listAnswer = new ArrayList<>();
                for(Comment reply : replyList){
                    Map<String, Object> mapReply = new HashMap<>();
                    mapReply.put("infoReply", reply);
                    countPraise = praiseService.checkCountPraiseEntity("reply", reply.getId());
                    mapReply.put("countPraiseReply", countPraise);
                    if(idUserCurrent != null){
                        boolean statusPraise = praiseService.checkStatusPraiseEntity(idUserCurrent, "reply", reply.getId());
                        mapReply.put("statusPraiseReply", statusPraise);
                    }
                    UserLogined userReply = userDao.selectUserLoginedById(reply.getIdUser());
                    mapReply.put("userReply", userReply);
                    /*判断有无明确@谁的回复，等于0表示没有@*/
                    if(reply.getIdTarget() != 0){
                        UserLogined userTarget = userDao.selectUserLoginedById(reply.getIdTarget());
                        mapReply.put("userTarget", userTarget);
                    }
                    listAnswer.add(mapReply);
                }
                mapComment.put("listAnswer", listAnswer);
                if("top".equals(comment.getStatus())){
                    listDiscussionOfficial.add(mapComment);
                }else{
                    listDiscussion.add(mapComment);
                }
            }
            map.put("listDiscussion", listDiscussion);
            map.put("listDiscussionOfficial", listDiscussionOfficial);
        }
        return map;
    }

    @Override
    public int checkCountByIdUser(Integer idUser) {
        int count = statementDao.selectCountByIdUser(idUser);
        return count;
    }

    @Override
    public Map<String, Object> queryByIdUser(Integer idUser, int pageIndex, int pageSize) {
        Map<String, Object> map = new HashMap<>();
        PageHelper.startPage(pageIndex, pageSize);
        List<Statement> statementList = statementDao.selectListByIdUser(idUser);
        for(Statement statement : statementList){
            long countPraise = praiseService.checkCountPraiseEntity("statement", statement.getId());
            statement.setCountPraise((int) countPraise);
        }
        map.put("statementList", statementList);
        return map;
    }

    @Override
    public Statement checkById(Integer id) {
        Statement statement = statementDao.selectStatementById(id);
        return statement;
    }

    @Override
    public Integer reviseStatusById(Integer id, String status) {
        Integer num = statementDao.updateStatusById(id, status);
        return num;
    }

    @Override
    public Integer reviseTypeById(Integer id, String type) {
        Integer num = statementDao.updateTypeById(id, type);
        return num;
    }
}
