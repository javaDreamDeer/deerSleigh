package com.itcampus.service.impl;

import com.github.pagehelper.PageHelper;
import com.itcampus.dao.CommentDao;
import com.itcampus.dao.StatementDao;
import com.itcampus.dao.UserDao;
import com.itcampus.domain.Comment;
import com.itcampus.domain.Statement;
import com.itcampus.domain.User;
import com.itcampus.service.CommentService;
import com.itcampus.service.PraiseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class CommentServiceImpl implements CommentService {

    @Resource
    private CommentDao commentDao;

    @Resource
    private StatementDao statementDao;

    @Resource
    private UserDao userDao;

    public void setCommentDao(CommentDao commentDao) {
        this.commentDao = commentDao;
    }

    public void setStatementDao(StatementDao statementDao) {
        this.statementDao = statementDao;
    }

    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }

    @Override
    public int checkCommentCountByIdEntityTypeEntity(Integer idEntity, String typeEntity) {
        int count = commentDao.selectCommentCountByIdEntityTypeEntity(idEntity, typeEntity);
        return count;
    }

    /*这是一个事务*/
    @Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
    @Override
    public Map<String, Object> increaseComment(Comment comment) throws SQLException, IllegalAccessException {
        Map<String, Object> map = new HashMap<>();
        Integer num = null;
        if("comment".equals(comment.getTypeEntity())){
            Statement statementTest = statementDao.selectStatementById(comment.getIdEntity());
            if(statementTest == null){
                throw new IllegalAccessException("非法增加评论，评论所在的发布贴不存在");
            }
            /*如果存在*/
            num = commentDao.insertComment(comment);
            if(num != 1){
                throw new SQLException("插入评论失败");
            }
            Integer countComment = statementTest.getCountComment() + 1;
            num = statementDao.updateCountCommentById(comment.getIdEntity(), countComment);
            if(num != 1){
                throw new SQLException("增加评论后，宿海发布贴的评论数失败");
            }
        }else{
            Comment commentTest = commentDao.selectCommentById(comment.getIdEntity());
            if(commentTest == null){
                throw new IllegalAccessException("非法增加回复，回复所在的评论不存在");
            }
            if(comment.getIdTarget() != 0){
                User userTest = userDao.selectUserById(comment.getIdTarget());
                if(userTest == null){
                    throw new IllegalAccessException("非法增加回复，回复所指向的用户不存在");
                }
            }
            /*没有参数问题*/
            num = commentDao.insertComment(comment);
            if(num != 1){
                throw new SQLException("插入回复失败");
            }
        }
        map.put("success", "success");
        return map;
    }

    @Override
    public int checkCountByIdUser(Integer idUser) {
        int count = commentDao.selectCountByIdUser(idUser);
        return count;
    }

    @Override
    public Map<String, Object> queryByIdUser(Integer idUser, int pageIndex, int pageSize) {
        Map<String, Object> map = new HashMap<>();
        PageHelper.startPage(pageIndex, pageSize);
        List<Comment> commentList = commentDao.selectListByIdUser(idUser);
        List<Map<String, Object>> list = new ArrayList<>();
        for(Comment comment : commentList){
            Map<String, Object> mapComment = new HashMap<>();
            mapComment.put("comment", comment);
            /*找出当前评论或回复所在发布贴的页数，先找出当前评论在第几个位置*/
            int countBefore  = 0;
            /*如果是回复型评论，要手动找出发布贴的id*/
            if("reply".equals(comment.getTypeEntity())){
                Comment commentTarget = commentDao.selectCommentById(comment.getIdEntity());
                mapComment.put("entityTarget", commentTarget);
                countBefore = commentDao.selectCountBeforeByComment(commentTarget);
            }else{
                /*非回复型评论，找出目标发布贴信息*/
                Statement statement = statementDao.selectStatementById(comment.getIdEntity());
                mapComment.put("entityTarget", statement);
                countBefore = commentDao.selectCountBeforeByComment(comment);
            }
            /*发布贴是每页5条数据*/
            int pageIndexStatement = (countBefore % 5 == 0)?(countBefore / 5):(countBefore / 5 + 1);
            mapComment.put("pageIndexStatement", pageIndexStatement);
            list.add(mapComment);
        }
        map.put("commentList", list);
        return map;
    }

    @Override
    public Comment checkById(Integer id) {
        Comment comment = commentDao.selectCommentById(id);
        return comment;
    }

    @Override
    public Integer reviseStatusById(Integer id, String status) {
        Integer num = commentDao.updateStatusById(id, status);
        return num;
    }
}
