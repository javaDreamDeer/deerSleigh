package com.itcampus.service.impl;

import com.itcampus.service.StudyService;
import com.itcampus.dao.StudyDao;
import com.itcampus.domain.Study;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class StudyServiceImpl implements StudyService {

    @Resource
    private StudyDao studyDao;

    public void setStudyDao(StudyDao studyDao) {
        this.studyDao = studyDao;
    }

    @Override
    public List<Study> queryList() {
        List<Study> studyList = studyDao.selectList();
        return studyList;
    }
}
