package com.itcampus.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class UserLogined {
    private Integer id;
    private String username;
    private String email;
    private String urlHeader;
    private String identity;
    private String conditions;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Shanghai")
    private Date timeCreate;

    private String college;
    private String major;
    private Integer grades;
    private String classes;
    private String nameTrue;
    private String nameTrueUse;
}
