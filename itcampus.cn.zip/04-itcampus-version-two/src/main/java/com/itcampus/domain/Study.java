package com.itcampus.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Study {
    private Integer id;
    private String type;
    private String realm;
    private String detail;
    private String source;
    private String title;
    private String content;
    private String url;
}
