package com.itcampus.domain;

public class Page {
    private int pageIndex = 1;
    private int pageSize = 10;
    private int dataRows;
    private String path;
    private int pageTotal;

    public int getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(int pageIndex) {
        if(pageIndex >= 1){
            this.pageIndex = pageIndex;
        }
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        if(pageSize >= 1 && pageSize <= 100){
            this.pageSize = pageSize;
        }
    }


    public int getDataRows() {
        return dataRows;
    }

    public void setDataRows(int dataRows) {
        if(dataRows >= 0){
            this.dataRows = dataRows;
        }
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public int getPageTotal() {
        if(dataRows % pageSize == 0){
            this.pageTotal = dataRows / pageSize;
        }else{
            this.pageTotal = dataRows / pageSize + 1;
        }
        return this.pageTotal;
    }

    public int getShowStart() {
        if(pageIndex - 2 < 1){
            return 1;
        }else{
            return pageIndex - 2;
        }
    }

    public int getShowEnd() {
        if((pageIndex + 2) > getPageTotal()){
            return getPageTotal();
        }else{
            return pageIndex + 2;
        }
    }

    public int getDataBegin(){
        return (pageIndex - 1) * pageSize + 1;
    }
}
