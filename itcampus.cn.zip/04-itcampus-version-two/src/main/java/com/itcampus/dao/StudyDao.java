package com.itcampus.dao;

import com.itcampus.domain.Study;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface StudyDao {
    List<Study> selectList();
}
