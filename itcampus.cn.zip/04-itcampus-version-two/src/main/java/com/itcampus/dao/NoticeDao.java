package com.itcampus.dao;

import com.itcampus.domain.Notice;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface NoticeDao {

    Integer insert(Notice notice);

    Integer selectUnreadCount(@Param("idUserTarget") Integer idUserTarget,
                              @Param("status") String status);

    List<Notice> selectListByIdUserTarget(Integer idUserTarget);

    List<Notice> selectListByIdUserTargetTypeEvent(@Param("idUserTarget") Integer idUserTarget,
                                                   @Param("typeEvent") String typeEvent);

    int selectCountByTypeEvent(@Param("idUserTarget") Integer idUserTarget,
                               @Param("typeEvent") String typeEvent);

    Integer updateStatusByIdList(@Param("idList") List<Integer> idList,
                                 @Param("status") String status);

    Integer updateStatusById(@Param("id") Integer id,
                             @Param("status") String status);

    List<Integer> selectIdListByIdUserTargetTypeEvent(@Param("idUserTarget") Integer idUserTarget,
                                                      @Param("typeEvent") String typeEvent);
}
