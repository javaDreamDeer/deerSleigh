package com.itcampus.dao;

import com.itcampus.domain.Message;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface MessageDao {

    List<Message> selectConversationList(Integer idUser);

    Integer selectConversationCount(Integer idUser);

    List<Message> selectLetterList(String idConversation);

    Integer selectLetterCount(String idConversation);

    Integer selectLetterUnreadCount(@Param("idReceiver") Integer idReceiver,
                                    @Param("idConversation") String idConversation);

    Integer insertLetter(Message message);

    Integer updateStatusByIdList(@Param("idList") List<Integer> idList,
                                 @Param("status") String status);

    Message selectById(Integer id);

    Integer updateStatusByIdStatus(@Param("id") Integer id,
                                   @Param("status") String status);
}
