package com.itcampus.dao;

import com.itcampus.domain.University;
import com.itcampus.domain.User;
import com.itcampus.domain.UserLogined;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface UserDao {
    List<User> selectUserList();

    User selectUserById(Integer id);

    Integer insertUser(User user);

    User selectUserByUsername(String username);

    User selectUserByEmail(String email);

    User selectUserByIdCodeActivate(@Param("id") Integer id, @Param("codeActivate") String codeActivate);

    Integer updateStatusById(@Param("id") Integer id, @Param("status") String status);

    UserLogined selectUserLoginedByUsername(String username);

    Integer updateUrlHeaderById(@Param("id") Integer id,
                                @Param("urlHeader") String urlHeader);

    Integer updatePasswordById(@Param("id") Integer id,
                               @Param("password") String password,
                               @Param("random") String random);

    Integer updateCollegeMajorGradesClassesNameTrueById(UserLogined userLogined);

    UserLogined selectUserLoginedById(Integer id);
}
