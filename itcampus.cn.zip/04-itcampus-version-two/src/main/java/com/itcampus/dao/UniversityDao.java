package com.itcampus.dao;

import com.itcampus.domain.University;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface UniversityDao {

    University selectByUniversity(University university);

    List<String> selectCollegeListDistinct();

    List<String> selectMajorListByCollege(String college);

    List<Integer> selectGradesListByCollegeMajor(@Param("college") String college,
                                                 @Param("major") String major);

    List<String> selectClassesListByCollegeMajorGrades(@Param("college") String college,
                                                       @Param("major") String major,
                                                       @Param("grades") Integer grades);

    List<String> selectMajorListDistinct();
}
