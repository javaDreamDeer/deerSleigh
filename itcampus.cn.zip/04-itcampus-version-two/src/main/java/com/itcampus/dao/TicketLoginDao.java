package com.itcampus.dao;

import com.itcampus.domain.TicketLogin;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface TicketLoginDao {
    Integer insertTicketLogin(TicketLogin ticketLogin);

    Integer updateStatusByIdUsername(@Param("id") Integer id,
                                     @Param("username") String username,
                                     @Param("status") String status);

    TicketLogin selectByUsernameTicketStatus(@Param("username") String username,
                                             @Param("ticket") String ticket,
                                             @Param("status") String status);

    Integer updateStatusById(@Param("id") Integer id,
                             @Param("status") String status);

    TicketLogin selectByUsernameStatus(@Param("username") String username,
                                       @Param("status") String status);
}
