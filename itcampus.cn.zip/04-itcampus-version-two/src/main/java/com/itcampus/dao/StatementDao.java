package com.itcampus.dao;

import com.itcampus.domain.Statement;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface StatementDao {

    List<Statement> selectStatementList();

    Integer selectStatementCount();

    Integer insertStatement(Statement statement);

    Statement selectStatementById(Integer id);

    Integer updateCountCommentById(@Param("id") Integer id,
                                   @Param("countComment") Integer countComment);

    int selectCountByIdUser(Integer idUser);

    List<Statement> selectListByIdUser(Integer idUser);

    Integer updateStatusById(@Param("id") Integer id,
                             @Param("status") String status);

    int selectCountBeforeById(@Param("idUser") Integer idUser,
                              @Param("id") Integer id);

    Integer updateTypeById(@Param("id") Integer id,
                           @Param("type") String type);
}
