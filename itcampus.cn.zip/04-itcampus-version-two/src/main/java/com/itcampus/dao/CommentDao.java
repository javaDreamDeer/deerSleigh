package com.itcampus.dao;

import com.itcampus.domain.Comment;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface CommentDao {

    List<Comment> selectCommentListByIdEntityTypeEntity(@Param("idEntity") Integer idEntity,
                                              @Param("typeEntity") String typeEntity);

    int selectCommentCountByIdEntityTypeEntity(@Param("idEntity") Integer idEntity,
                                               @Param("typeEntity") String typeEntity);

    Comment selectCommentById(Integer id);

    Integer insertComment(Comment comment);

    int selectCountByIdUser(Integer idUser);

    List<Comment> selectListByIdUser(Integer idUser);

    int selectCountBeforeByComment(Comment comment);

    Integer updateStatusById(@Param("id") Integer id,
                             @Param("status") String status);

    int selectCountBeforeById(@Param("idUser") Integer idUser,
                              @Param("id") Integer id);
}
