package com.itcampus.handler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

@ControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler
    public ModelAndView doOtherException(Exception exception){
        logger.error("系统后台出错: " + exception.getMessage());
        ModelAndView mv = new ModelAndView();
        mv.addObject("exceptionMsg", "系统后台出错！");
        mv.addObject("exceptionDetail",exception);
        mv.setViewName("error/500");
        return mv;
    }
}
