package com.itcampus.controller;

import com.itcampus.annotation.LoginRequired;
import com.itcampus.domain.Page;
import com.itcampus.domain.UserLogined;
import com.itcampus.service.*;
import com.itcampus.utils.HostHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;

@Controller
@RequestMapping(value = "/profile")
public class ProfileController {

    @Autowired
    private UserService userService;

    @Autowired
    private StatementService statementService;

    @Autowired
    private CommentService commentService;

    @Autowired
    private PraiseService praiseService;

    @Autowired
    private FollowService followService;

    @Autowired
    private HostHolder hostHolder;

    /*当前登录用户的主页*/
    @LoginRequired
    @RequestMapping(value = "", method = RequestMethod.GET)
    public String getUserSelfProfilePage(Model model) throws IllegalAccessException {
        UserLogined userLogined = hostHolder.getUser();
        if(userLogined == null){
            throw new IllegalAccessException("非法访问自己的个人主页，当前线程找不到登录用户");
        }
        model.addAttribute("userLogined", userLogined);
        model.addAttribute("user", userLogined);
        Integer countPraise = praiseService.checkCountPraiseUser(userLogined.getId());
        model.addAttribute("countPraise", countPraise);
        /*获取用户关注数量和粉丝数量*/
        long countFollowee = followService.checkCountFollowee(userLogined.getId(), "user");
        model.addAttribute("countFollowee", countFollowee);
        long countFollower = followService.checkCountFollower("user", userLogined.getId());
        model.addAttribute("countFollower", countFollower);
        return "site/profile";
    }

    /*其他用户*/
    @RequestMapping(value = "/{idUser}", method = RequestMethod.GET)
    public String getUserProfilePage(Model model,
                                     @PathVariable("idUser") Integer idUser) throws IllegalAccessException {
        if(idUser == null){
            throw new IllegalAccessException("非法访问用户首页，用户标识为空");
        }
        UserLogined userLogined = hostHolder.getUser();
        model.addAttribute("userLogined", userLogined);
        UserLogined user = userService.checkUserLoginedById(idUser);
        model.addAttribute("user", user);
        Integer countPraise = praiseService.checkCountPraiseUser(idUser);
        model.addAttribute("countPraise", countPraise);
        /*判断当前用户是否被登录用户所关注*/
        String status = followService.checkStatusFollowed(userLogined != null ? userLogined.getId() : null, "user", idUser);
        model.addAttribute("statusFollow", status);
        /*获取用户关注数量和粉丝数量*/
        long countFollowee = followService.checkCountFollowee(idUser, "user");
        model.addAttribute("countFollowee", countFollowee);
        long countFollower = followService.checkCountFollower("user", idUser);
        model.addAttribute("countFollower", countFollower);
        return "site/profile";
    }

    /*用户的发布*/
    @RequestMapping(value = {"/statement","/statement/{idUser}"}, method = RequestMethod.GET)
    public String profileStatement(Model model,
                                   @PathVariable(value = "idUser", required = false) Integer idUser,
                                   @RequestParam(value = "pageIndex", required = false, defaultValue = "1") Integer pageIndex){
        UserLogined userLogined = hostHolder.getUser();
        model.addAttribute("userLogined", userLogined);
        UserLogined user = null;
        Page page = new Page();
        page.setPageIndex(pageIndex);
        page.setPageSize(10);
        if(idUser == null){
            page.setPath("/profile/statement");
            user = userLogined;
        }else{
            page.setPath("/profile/statement/" + idUser);
            user = userService.checkUserLoginedById(idUser);
        }
        model.addAttribute("user", user);
        page.setDataRows(statementService.checkCountByIdUser(user.getId()));
        model.addAttribute("page", page);
        Map<String, Object> map = statementService.queryByIdUser(user.getId(), page.getPageIndex(), page.getPageSize());
        model.addAttribute("map", map);
        return "site/my-statement";
    }

    /*用户的评论*/
    @RequestMapping(value = {"/comment","/comment/{idUser}"}, method = RequestMethod.GET)
    public String profileComment(Model model,
                                 @PathVariable(value = "idUser", required = false) Integer idUser,
                                 @RequestParam(value = "pageIndex", required = false, defaultValue = "1") Integer pageIndex){
        UserLogined userLogined = hostHolder.getUser();
        model.addAttribute("userLogined", userLogined);
        UserLogined user = null;
        Page page = new Page();
        page.setPageIndex(pageIndex);
        page.setPageSize(10);
        if(idUser == null){
            page.setPath("/profile/comment");
            user = userLogined;
        }else{
            page.setPath("/profile/comment/" + idUser);
            user = userService.checkUserLoginedById(idUser);
        }
        model.addAttribute("user", user);
        page.setDataRows(commentService.checkCountByIdUser(user.getId()));
        model.addAttribute("page", page);
        Map<String, Object> map = commentService.queryByIdUser(user.getId(), page.getPageIndex(), page.getPageSize());
        model.addAttribute("map", map);
        return "site/my-comment";
    }

}
