package com.itcampus.controller;

import com.itcampus.domain.Study;
import com.itcampus.service.StudyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.ArrayList;
import java.util.List;

@Controller
public class StudyController {

    @Autowired
    private StudyService studyService;

    @RequestMapping(value = "/study", method = RequestMethod.GET)
    public String study(Model model){
        return "site/study";
    }

    @RequestMapping(value = "/study/{realm}", method = RequestMethod.GET)
    public String studyRealm(Model model,
                             @PathVariable(value = "realm", required = false) String realm){
        if(realm == null){
            realm = "java";
        }
        model.addAttribute("realmCurrent", realm);
        List<Study> studyList = studyService.queryList();
        List<Study> javaRouteList = new ArrayList<>();
        List<Study> javaSystemList = new ArrayList<>();
        List<Study> javaTechnologyList = new ArrayList<>();
        List<Study> javaUserList = new ArrayList<>();
        List<Study> webRouteList = new ArrayList<>();
        List<Study> webSystemList = new ArrayList<>();
        List<Study> webTechnologyList = new ArrayList<>();
        List<Study> webUserList = new ArrayList<>();
        List<Study> pythonRouteList = new ArrayList<>();
        List<Study> pythonSystemList = new ArrayList<>();
        List<Study> pythonTechnologyList = new ArrayList<>();
        List<Study> pythonUserList = new ArrayList<>();
        List<Study> bigdataRouteList = new ArrayList<>();
        List<Study> bigdataSystemList = new ArrayList<>();
        List<Study> bigdataTechnologyList = new ArrayList<>();
        List<Study> bigdataUserList = new ArrayList<>();
        for (Study study : studyList){
            if("java".equals(study.getRealm())){
                if("route".equals(study.getType())){
                    javaRouteList.add(study);
                }else if("system".equals(study.getType())){
                    javaSystemList.add(study);
                }else if("technology".equals(study.getType())){
                    javaTechnologyList.add(study);
                }else if("user".equals(study.getType())){
                    javaUserList.add(study);
                }
            }else if("web".equals(study.getRealm())){
                if("route".equals(study.getType())){
                    webRouteList.add(study);
                }else if("system".equals(study.getType())){
                    webSystemList.add(study);
                }else if("technology".equals(study.getType())){
                    webTechnologyList.add(study);
                }else if("user".equals(study.getType())){
                    webUserList.add(study);
                }
            }else if("python".equals(study.getRealm())){
                if("route".equals(study.getType())){
                    pythonRouteList.add(study);
                }else if("system".equals(study.getType())){
                    pythonSystemList.add(study);
                }else if("technology".equals(study.getType())){
                    pythonTechnologyList.add(study);
                }else if("user".equals(study.getType())){
                    pythonUserList.add(study);
                }
            }else if("bigdata".equals(study.getRealm())){
                if("route".equals(study.getType())){
                    bigdataRouteList.add(study);
                }else if("system".equals(study.getType())){
                    bigdataSystemList.add(study);
                }else if("technology".equals(study.getType())){
                    bigdataTechnologyList.add(study);
                }else if("user".equals(study.getType())){
                    bigdataUserList.add(study);
                }
            }else{
                if("route".equals(study.getType())){
                    javaRouteList.add(study);
                    webRouteList.add(study);
                    pythonRouteList.add(study);
                    bigdataRouteList.add(study);
                }else if("system".equals(study.getType())){
                    javaSystemList.add(study);
                    webSystemList.add(study);
                    pythonSystemList.add(study);
                    bigdataSystemList.add(study);
                }else if("technology".equals(study.getType())){
                    javaTechnologyList.add(study);
                    webTechnologyList.add(study);
                    pythonTechnologyList.add(study);
                    bigdataTechnologyList.add(study);
                }else if("user".equals(study.getType())){
                    javaUserList.add(study);
                    webUserList.add(study);
                    pythonUserList.add(study);
                    bigdataUserList.add(study);
                }
            }
        }
        model.addAttribute("javaRouteList", javaRouteList);
        model.addAttribute("javaSystemList", javaSystemList);
        model.addAttribute("javaTechnologyList", javaTechnologyList);
        model.addAttribute("javaUserList", javaUserList);
        model.addAttribute("webRouteList", webRouteList);
        model.addAttribute("webSystemList", webSystemList);
        model.addAttribute("webTechnologyList", webTechnologyList);
        model.addAttribute("webUserList", webUserList);
        model.addAttribute("pythonRouteList", pythonRouteList);
        model.addAttribute("pythonSystemList", pythonSystemList);
        model.addAttribute("pythonTechnologyList", pythonTechnologyList);
        model.addAttribute("pythonUserList", pythonUserList);
        model.addAttribute("bigdataRouteList", bigdataRouteList);
        model.addAttribute("bigdataSystemList", bigdataSystemList);
        model.addAttribute("bigdataTechnologyList", bigdataTechnologyList);
        model.addAttribute("bigdataUserList", bigdataUserList);
        return "site/study-detail";
    }
}
