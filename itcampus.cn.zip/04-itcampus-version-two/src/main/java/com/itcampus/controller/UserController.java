package com.itcampus.controller;

import com.alibaba.fastjson.JSON;
import com.itcampus.annotation.LoginRequired;
import com.itcampus.domain.University;
import com.itcampus.domain.User;
import com.itcampus.domain.UserLogined;
import com.itcampus.service.UniversityService;
import com.itcampus.service.UserService;
import com.itcampus.utils.HostHolder;
import com.itcampus.utils.RegexValidateUtil;
import com.itcampus.utils.SecurityUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/user")
public class UserController {

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserService userService;

    @Autowired
    private UniversityService universityService;

    @Autowired
    private HostHolder hostHolder;

    @Value("${itcampus.path.upload}")
    private String uploadPath;

    @Value("${itcampus.com}")
    private String domainName;

    @Value("${server.servlet.context-path}")
    private String contextPath;

    /*登录之后才可以访问*/
    @LoginRequired
    @RequestMapping(value = {"/setting", "/setting/information"}, method = RequestMethod.GET)
    public String getSettingPage(Model model) throws IllegalAccessException {
        model.addAttribute("informationPage", "informationPage");
        /*默认给表单赋值*/
        UserLogined userLogined = hostHolder.getUser();
        if(userLogined == null){
            throw new IllegalAccessException("非法访问，当前线程找不到用户信息");
        }
        model.addAttribute("userLogined", userLogined);
        /*光传默认值还不够，默认先给出学院的下拉列表*/
        /*获取学院列表*/
        List<String> collegeList = universityService.queryCollegeListDistinct();
        model.addAttribute("collegeList", collegeList);
        if(userLogined.getCollege() != null){
            /*获取专业列表*/
            List<String> majorList = universityService.queryMajorListByCollege(userLogined.getCollege());
            model.addAttribute("majorList", majorList);
            /*获取年级列表*/
            List<Integer> gradesList = universityService.queryGradesListByCollegeMajor(userLogined.getCollege(), userLogined.getMajor());
            model.addAttribute("gradesList", gradesList);
            /*获取班级列表*/
            List<String> classesList = universityService.queryClassesListByCollegeMajorGrades(userLogined.getCollege(), userLogined.getMajor(), userLogined.getGrades());
            model.addAttribute("classesList", classesList);
        }
        return "site/setting";
    }

    /*专业联动*/
    /*登录之后才可以访问*/
    @LoginRequired
    @ResponseBody
    @RequestMapping(value = "/setting/information/major", method = RequestMethod.POST)
    public String getMajorByCollege(@RequestParam("college") String college) throws IllegalAccessException {
        if(StringUtils.isEmpty(college) || StringUtils.isBlank(college)){
            throw new IllegalAccessException("非法查询专业，学院为空");
        }
        List<String> majorList = universityService.queryMajorListByCollege(college);
        if(majorList == null){
            throw new IllegalAccessException("非法查询专业，学院不存在");
        }
        String jsonString = JSON.toJSONString(majorList);
        return jsonString;
    }

    /*年级联动*/
    /*登录之后才可以访问*/
    @LoginRequired
    @ResponseBody
    @RequestMapping(value = "/setting/information/grades", method = RequestMethod.POST)
    public String getGradesByCollegeMajor(@RequestParam("college") String college,
                                          @RequestParam("major") String major) throws IllegalAccessException {
        if(StringUtils.isEmpty(college) || StringUtils.isBlank(college)){
            throw new IllegalAccessException("非法查询年级，学院为空");
        }
        if(StringUtils.isEmpty(major) || StringUtils.isBlank(major)){
            throw new IllegalAccessException("非法查询年级，专业为空");
        }
        List<Integer> gradesList = universityService.queryGradesListByCollegeMajor(college, major);
        if(gradesList == null){
            throw new IllegalAccessException("非法查询年级，学院专业不存在");
        }
        String jsonString = JSON.toJSONString(gradesList);
        return jsonString;
    }

    /*班级联动*/
    /*登录之后才可以访问*/
    @LoginRequired
    @ResponseBody
    @RequestMapping(value = "/setting/information/classes", method = RequestMethod.POST)
    public String getClassesByCollegeMajorGrades(@RequestParam("college") String college,
                                                 @RequestParam("major") String major,
                                                 @RequestParam("grades") Integer grades) throws IllegalAccessException {
        if(StringUtils.isEmpty(college) || StringUtils.isBlank(college)){
            throw new IllegalAccessException("非法查询年级，学院为空");
        }
        if(StringUtils.isEmpty(major) || StringUtils.isBlank(major)){
            throw new IllegalAccessException("非法查询年级，专业为空");
        }
        if(grades == null){
            throw new IllegalAccessException("非法查询年级，专业为空");
        }
        List<String> classesList = universityService.queryClassesListByCollegeMajorGrades(college, major, grades);
        if(classesList == null){
            throw new IllegalAccessException("非法查询年级，学院专业年级不存在");
        }
        String jsonString = JSON.toJSONString(classesList);
        return jsonString;
    }

    /*登录之后才可以访问*/
    @LoginRequired
    @RequestMapping(value = "/setting/secret", method = RequestMethod.GET)
    public String getSecretPath(Model model){
        model.addAttribute("secretPage", "secretPage");
        return "site/setting";
    }

    /*登录之后才可以访问*/
    @LoginRequired
    @RequestMapping(value = "/setting/upload", method = RequestMethod.GET)
    public String getUploadPath(Model model){
        model.addAttribute("uploadPage", "uploadPage");
        return "site/setting";
    }

    /*登录之后才可以访问*/
    /*这是一个事务*/
    @LoginRequired
    @Transactional
    @RequestMapping(value = "/setting/upload", method = RequestMethod.POST)
    public String uploadHeader(Model model,
                               MultipartFile imageHeader) throws SQLException, IllegalAccessException {
        model.addAttribute("uploadPage", "uploadPage");
        if (imageHeader == null) {
            model.addAttribute("imageMsg", "您还没有选择图片!");
            return "site/setting";
        }
        /*获取文件原名称，并提取后缀名*/
        String fileName = imageHeader.getOriginalFilename();
        assert fileName != null;
        String suffix = fileName.substring(fileName.lastIndexOf("."));
        if (StringUtils.isBlank(suffix)) {
            model.addAttribute("imageMsg", "文件格式不明确！");
            return "site/setting";
        }
        String[] imageSuffix = {".jpg",".png",".jpeg",".gif",".bmp"};
        boolean flag = Arrays.asList(imageSuffix).contains(suffix);
        if(!flag){
            model.addAttribute("imageMsg", "系统无法识别该格式的图片文件！");
            return "site/setting";
        }
        // 生成随机文件名
        fileName = SecurityUtil.generateUUID() + suffix;
        // 确定文件存放的路径
        File dest = new File(uploadPath + "/" + fileName);
        try {
            // 存储文件
            imageHeader.transferTo(dest);
        } catch (IOException e) {
            logger.error("上传头像失败: " + e.getMessage());
            throw new RuntimeException("上传文件失败，服务器发生异常", e);
        }

        // 更新当前用户的头像的路径(web访问路径)
        // http://localhost:8080/itcampus/user/header/xxx.png
        UserLogined userLogined = hostHolder.getUser();
        if(userLogined == null){
            throw new IllegalAccessException("非法访问，当前线程找不到用户信息");
        }
        String urlHeader = domainName + contextPath + "/user/header/" + fileName;
        Integer num = userService.reviseUrlHeaderByUsername(userLogined.getId(), urlHeader);
        if(num != 1){
            logger.error("修改用户头像地址失败");
            throw new SQLException("更新数据库异常，修改用户头像失败");
        }
        return "redirect:/main";
    }

    @RequestMapping(value = "/header/{fileName}", method = RequestMethod.GET)
    public void getHeader(@PathVariable("fileName") String fileName,
                          HttpServletResponse response) {
        // 服务器存放路径
        fileName = uploadPath + "/" + fileName;
        // 文件后缀
        String suffix = fileName.substring(fileName.lastIndexOf("."));
        // 响应图片
        response.setContentType("image/" + suffix);
        FileInputStream fileInputStream = null;
        OutputStream outputStream = null;
        try {
            fileInputStream = new FileInputStream(fileName);
            outputStream = response.getOutputStream();
            byte[] buffer = new byte[1024];
            int bit = 0;
            while ((bit = fileInputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bit);
            }
            /*fileInputStream.close();
            outputStream.close();*/
        } catch (IOException e) {
            logger.error("读取更换的头像失败: " + e.getMessage());
        } finally {
            if (fileInputStream != null){
                try {
                    fileInputStream.close();
                } catch (IOException e){
                    logger.warn("读取头像后，关闭fileInputStream流失败: " + e.getMessage());
                }
            }
            if (outputStream != null){
                try {
                    outputStream.close();
                } catch (IOException e){
                    logger.warn("读取头像后，关闭outputStream流失败: " + e.getMessage());
                }
            }
        }
    }

    /*登录之后才可以访问*/
    @LoginRequired
    @RequestMapping(value = "/setting/information", method = RequestMethod.POST)
    public String changeInformation(Model model,
                                    UserLogined userLogined,
                                    @RequestParam(value = "replace", required = false, defaultValue = "false") boolean replace) throws IllegalAccessException, SQLException {
        model.addAttribute("informationPage", "informationPage");

        if(userLogined== null){
            throw new IllegalAccessException("非法修改信息，信息对象为空");
        }
        /*获取学院列表*/
        List<String> collegeList = universityService.queryCollegeListDistinct();
        model.addAttribute("collegeList", collegeList);
        if(StringUtils.isEmpty(userLogined.getCollege()) || StringUtils.isBlank(userLogined.getCollege())){
            model.addAttribute("alterWarning", "学院为空！");
            return "site/setting";
        }
        /*获取专业列表*/
        List<String> majorList = universityService.queryMajorListByCollege(userLogined.getCollege());
        model.addAttribute("majorList", majorList);
        if(StringUtils.isEmpty(userLogined.getMajor()) || StringUtils.isBlank(userLogined.getMajor())){
            model.addAttribute("alterWarning", "专业为空！");
            return "site/setting";
        }
        /*获取年级列表*/
        List<Integer> gradesList = universityService.queryGradesListByCollegeMajor(userLogined.getCollege(), userLogined.getMajor());
        model.addAttribute("gradesList", gradesList);
        if(userLogined.getGrades() == null){
            model.addAttribute("alterWarning", "年级为空！");
            return "site/setting";
        }
        /*获取班级列表*/
        List<String> classesList = universityService.queryClassesListByCollegeMajorGrades(userLogined.getCollege(), userLogined.getMajor(), userLogined.getGrades());
        model.addAttribute("classesList", classesList);
        if(StringUtils.isEmpty(userLogined.getClasses()) || StringUtils.isBlank(userLogined.getClasses())){
            model.addAttribute("alterWarning", "班级为空！");
            return "site/setting";
        }
        if(StringUtils.isEmpty(userLogined.getNameTrue()) || StringUtils.isBlank(userLogined.getNameTrue())){
            model.addAttribute("alterWarning", "真实名字为空！");
            return "site/setting";
        }
        if(!replace){
            userLogined.setNameTrueUse("no");
        }else{
            userLogined.setNameTrueUse("yes");
        }
        UserLogined userLoginedReturn = hostHolder.getUser();
        if(userLoginedReturn == null){
            throw new IllegalAccessException("非法访问，当前线程找不到用户信息");
        }
        userLogined.setId(userLoginedReturn.getId());
        userLogined.setUsername(userLoginedReturn.getUsername());
        /*更新Get方法返回的userLogin，实现POST方法复用userLogin*/
        userLoginedReturn.setCollege(userLogined.getCollege());
        userLoginedReturn.setMajor(userLogined.getMajor());
        userLoginedReturn.setGrades(userLogined.getGrades());
        userLoginedReturn.setClasses(userLogined.getClasses());
        userLoginedReturn.setNameTrue(userLogined.getNameTrue());
        userLoginedReturn.setNameTrueUse(userLogined.getNameTrueUse());
        model.addAttribute("userLogin", userLoginedReturn);
        /*调用Service方法*/
        Map<String, Object> map = userService.reviseInformation(userLogined);
        if(map.get("success") != null){
            model.addAttribute("alterSuccess", "信息保存成功！");
        }else{
            model.addAttribute("alterWarning", map.get("alterWarning"));
            model.addAttribute("alterError", map.get("alterError"));
            model.addAttribute("alterErrorLink", "/login");
        }
        return "site/setting";
    }

    /*登录之后才可以访问*/
    @LoginRequired
    @RequestMapping(value = "/setting/secret", method = RequestMethod.POST)
    public String changePassword(Model model,
                                 @RequestParam("passwordOld") String passwordOld,
                                 @RequestParam("passwordNew") String passwordNew) throws IllegalAccessException, SQLException {
        model.addAttribute("secretPage", "secretPage");
        if(StringUtils.isEmpty(passwordOld) || StringUtils.isBlank(passwordOld)){
            throw new IllegalAccessException("非法修改密码，原密码为空");
        }
        if(StringUtils.isEmpty(passwordNew) || StringUtils.isBlank(passwordNew)){
            throw new IllegalAccessException("非法修改密码，新密码为空");
        }
        if(!RegexValidateUtil.validatePwd(passwordOld)){
            model.addAttribute("passwordOldMsg", "密码规则（8-16位字母或数字）");
            return "site/setting";
        }
        if(!RegexValidateUtil.validatePwd(passwordNew)){
            model.addAttribute("passwordNewMsg", "密码规则（8-16位字母或数字）");
            return "site/setting";
        }
        UserLogined userLogined = hostHolder.getUser();
        if(userLogined == null){
            throw new IllegalAccessException("非法访问，当前线程找不到用户信息");
        }
        Map<String,Object> map = userService.revisePassword(userLogined.getId(), passwordOld, passwordNew);
        if(map.get("success") != null){
            model.addAttribute("alterSuccess", "修改密码成功！");
            return "redirect:/login";
        }else{
            model.addAttribute("passwordOldMsg", map.get("passwordOldMsg"));
            model.addAttribute("alterError", map.get("alterError"));
            model.addAttribute("alterErrorLink", "/login");
            return "site/setting";
        }
    }
}
