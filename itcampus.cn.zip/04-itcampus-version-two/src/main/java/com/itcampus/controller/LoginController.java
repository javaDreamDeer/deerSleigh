package com.itcampus.controller;

import com.alibaba.fastjson.JSON;
import com.google.code.kaptcha.Producer;
import com.itcampus.annotation.LoginExpired;
import com.itcampus.annotation.LoginRequired;
import com.itcampus.domain.TicketLogin;
import com.itcampus.domain.User;
import com.itcampus.domain.UserLogined;
import com.itcampus.service.UserService;
import com.itcampus.utils.JsonResultMap;
import com.itcampus.utils.RedisKeyUtil;
import com.itcampus.utils.RegexValidateUtil;
import com.itcampus.utils.SecurityUtil;
import com.sun.deploy.net.HttpResponse;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.resource.HttpResource;

import javax.imageio.ImageIO;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Controller
public class LoginController {

    @Autowired
    private UserService userService;

    @Autowired
    private Producer kaptcheProducer;

    @Autowired
    private RedisTemplate redisTemplate;

    @Value("${server.servlet.context-path}")
    private String contextPath;

    @LoginExpired
    @RequestMapping(value = "/register", method = RequestMethod.GET)
    public String getRegisterPage(Model model){
        return "site/register";
    }

    @LoginExpired
    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public String registerByUser(Model model,
                                 User user,
                                 @RequestParam("captcha") String captcha,
                                 @CookieValue(value = "ownerCaptchaRegister", required = false) String ownerCaptchaRegister) throws SQLException, IllegalAccessException {
        if(user == null){
            throw new IllegalAccessException("非法注册，参数对象User为空");
        }
        if(StringUtils.isEmpty(user.getUsername()) || StringUtils.isBlank(user.getUsername())){
            throw new IllegalArgumentException("非法注册，用户名为空");
        }
        if(StringUtils.isEmpty(user.getPassword()) || StringUtils.isBlank(user.getPassword())){
            throw new IllegalArgumentException("非法注册，密码为空");
        }
        if(StringUtils.isEmpty(user.getEmail()) || StringUtils.isBlank(user.getEmail())){
            throw new IllegalArgumentException("非法注册，邮箱为空");
        }
        if(StringUtils.isEmpty(captcha) || StringUtils.isBlank(captcha)){
            throw new IllegalArgumentException("非法注册，验证码为空");
        }
        /*如果客户端的Cookie已经过期，提示用户*/
        if(ownerCaptchaRegister == null){
            model.addAttribute("alterWarning", "您的验证码已过期，请点击验证码图片更换一张！");
            return "site/register";
        }
        if(!RegexValidateUtil.validateUsername(user.getUsername())){
            model.addAttribute("usernameMsg", "用户名规则（汉字、英文单词或数字组合）");
            return "site/register";
        }
        if(!RegexValidateUtil.validateEmail(user.getEmail())){
            model.addAttribute("emailMsg", "邮箱格式不合法！");
            return "site/register";
        }
        if(!RegexValidateUtil.validatePwd(user.getPassword())){
            model.addAttribute("passwordMsg", "密码规则（8-16位字母或数字）");
            return "site/register";
        }
        /*判断验证码*/
        if(StringUtils.isEmpty(ownerCaptchaRegister) || StringUtils.isBlank(ownerCaptchaRegister)){
            model.addAttribute("captchaMsg", "验证码已过期，请刷新！");
            return "site/register";
        }
        String captchaKey = RedisKeyUtil.getCaptchaKey("register", ownerCaptchaRegister);
        String captchaRedis = (String) redisTemplate.opsForValue().get(captchaKey);
        if(captchaRedis == null){
            model.addAttribute("captchaMsg", "验证码已过期，请刷新！");
            return "site/register";
        }
        if(!captchaRedis.equals(captcha.toUpperCase())){
            model.addAttribute("captchaMsg", "验证码不正确！");
            return "site/register";
        }
        Map<String, Object> map = userService.register(user);
        if(map.get("success") == "success"){
            model.addAttribute("msg", "注册成功，激活链接已经发送到您的邮箱，请注意查收！");
            model.addAttribute("target", "/main");
            return "site/operate-result";
        }else{
            model.addAttribute("usernameMsg", map.get("usernameMsg"));
            model.addAttribute("passwordMsg", map.get("passwordMsg"));
            model.addAttribute("emailMsg", map.get("emailMsg"));
            return "site/register";
        }
    }

    /*激活账号*/
    @LoginExpired
    @RequestMapping(value = "/activate/{id}/{codeActivate}", method = RequestMethod.GET)
    public String activateByIdCodeActivate(Model model,
                                           @PathVariable("id") Integer id,
                                           @PathVariable("codeActivate") String codeActivate){
        User userTest = userService.checkUserByIdCodeActivate(id, codeActivate);
        if(userTest != null && userTest.getCodeActivate().equals(codeActivate)){
            if("down".equals(userTest.getStatus())){
                /*激活账号*/
                Integer num = userService.reviseStatusById(id, "up");
                model.addAttribute("msg", "您的账号激活成功，可立即登录！");
                model.addAttribute("target", "/login");
            }else{
                model.addAttribute("msg", "您的账号已经激活，可立即登录！");
                model.addAttribute("target", "/login");
            }
        }else{
            model.addAttribute("msg", "激活链接错误，激活失败！");
            model.addAttribute("target", "/main");
        }
        return "site/operate-result";
    }

    @LoginExpired
    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public String getLoginPage(Model model){
        return "site/login";
    }

    /*
     * 获取登录验证码*/
    @LoginExpired
    @RequestMapping(value = "/getCaptchaImagesLogin", method = RequestMethod.GET)
    public void getCaptchaImagesLogin(HttpServletResponse response){
        String text = kaptcheProducer.createText();
        BufferedImage image = kaptcheProducer.createImage(text);
        /*
         * 将登录验证码文本存储到Session中，方便之后验证
         * 这种方式也是暂时的，因为也要考虑多用户的并发情况，应该用redis储存*/
        //session.setAttribute("captchaTextLogin", text);
        /*将验证码存入Redis，定义验证码的所有者区分多用户并发*/
        String ownerCaptcha = SecurityUtil.generateUUID();
        Cookie cookie = new Cookie("ownerCaptchaLogin", ownerCaptcha);
        cookie.setMaxAge(180);
        cookie.setPath(contextPath);
        response.addCookie(cookie);
        String captchaKey = RedisKeyUtil.getCaptchaKey("login", ownerCaptcha);
        /*登录验证码设置3分钟的生命周期*/
        redisTemplate.opsForValue().set(captchaKey, text, 180, TimeUnit.SECONDS);

        /*将图片以字节流的方式输出给浏览器*/
        response.setContentType("image/png");
        try {
            OutputStream os = response.getOutputStream();
            ImageIO.write(image, "png", os);
        } catch (IOException e) {
            throw new InternalError("登录验证码字节流传输失败");
        }
    }

    /*
     * 获取注册验证码*/
    @LoginExpired
    @RequestMapping(value = "/getCaptchaImagesRegister", method = RequestMethod.GET)
    public void getCaptchaImagesRegister(HttpServletResponse response){
        String text = kaptcheProducer.createText();
        BufferedImage image = kaptcheProducer.createImage(text);
        /*将验证码存入Redis，定义验证码的所有者区分多用户并发*/
        String ownerCaptcha = SecurityUtil.generateUUID();
        Cookie cookie = new Cookie("ownerCaptchaRegister", ownerCaptcha);
        cookie.setMaxAge(300);
        cookie.setPath(contextPath);
        response.addCookie(cookie);
        String captchaKey = RedisKeyUtil.getCaptchaKey("register", ownerCaptcha);
        /*注册验证码设置5分钟的生命周期*/
        redisTemplate.opsForValue().set(captchaKey, text, 300, TimeUnit.SECONDS);
        /*将图片以字节流的方式输出给浏览器*/
        response.setContentType("image/png");
        try {
            OutputStream os = response.getOutputStream();
            ImageIO.write(image, "png", os);
        } catch (IOException e) {
            throw new InternalError("注册验证码字节流传输失败");
        }
    }

    /*
     * 获取找回密码验证码*/
    @LoginExpired
    @RequestMapping(value = "/getCaptchaImagesForget", method = RequestMethod.GET)
    public void getCaptchaImagesForget(HttpServletResponse response){
        String text = kaptcheProducer.createText();
        BufferedImage image = kaptcheProducer.createImage(text);
        /*将验证码存入Redis，定义验证码的所有者区分多用户并发*/
        String ownerCaptcha = SecurityUtil.generateUUID();
        Cookie cookie = new Cookie("ownerCaptchaForget", ownerCaptcha);
        cookie.setMaxAge(300);
        cookie.setPath(contextPath);
        response.addCookie(cookie);
        String captchaKey = RedisKeyUtil.getCaptchaKey("forget", ownerCaptcha);
        /*找回密码验证码设置5分钟的生命周期*/
        redisTemplate.opsForValue().set(captchaKey, text, 300, TimeUnit.SECONDS);
        /*将图片以字节流的方式输出给浏览器*/
        response.setContentType("image/png");
        try {
            OutputStream os = response.getOutputStream();
            ImageIO.write(image, "png", os);
        } catch (IOException e) {
            throw new InternalError("找回密码验证码字节流传输失败");
        }
    }


    @LoginExpired
    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public String loginByUser(Model model,
                              @RequestParam("username") String username,
                              @RequestParam("password") String password,
                              @RequestParam("captcha") String captcha,
                              @RequestParam(value = "remember", required=false, defaultValue="false") boolean remember,
                              @CookieValue(value = "ownerCaptchaLogin", required = false) String ownerCaptchaLogin,
                              HttpServletResponse response) throws SQLException, IllegalAccessException {
        if(StringUtils.isEmpty(username) || StringUtils.isBlank(username)){
            throw new IllegalArgumentException("非法登录，用户名或邮箱为空");
        }
        if(StringUtils.isEmpty(password) || StringUtils.isBlank(password)){
            throw new IllegalArgumentException("非法登录，密码为空");
        }
        if(StringUtils.isEmpty(captcha) || StringUtils.isBlank(captcha)){
            throw new IllegalArgumentException("非法登录，验证码为空");
        }
        /*如果客户端的Cookie已经过期，提示用户*/
        if(ownerCaptchaLogin == null){
            model.addAttribute("alterWarning", "您的验证码已过期，请点击验证码图片更换一张！");
            return "site/login";
        }
        if(!RegexValidateUtil.validateUsername(username) && !RegexValidateUtil.validateEmail(username)){
            model.addAttribute("usernameMsg", "用户名(汉字、英文单词或数字组合)输入不合法或者邮箱格式不合法");
            return "site/login";
        }
        if(!RegexValidateUtil.validatePwd(password)){
            model.addAttribute("passwordMsg", "密码规则（8-16位字母或数字）");
            return "site/login";
        }
        /*判断验证码，不区分大小写*/
        if(StringUtils.isEmpty(ownerCaptchaLogin) || StringUtils.isBlank(ownerCaptchaLogin)){
            model.addAttribute("captchaMsg", "验证码已过期，请刷新！");
            return "site/login";
        }
        String captchaKey = RedisKeyUtil.getCaptchaKey("login", ownerCaptchaLogin);
        String captchaRedis = (String) redisTemplate.opsForValue().get(captchaKey);
        if(captchaRedis == null){
            model.addAttribute("captchaMsg", "验证码已过期，请刷新！");
            return "site/login";
        }
        if(!captchaRedis.equals(captcha.toUpperCase())){
            model.addAttribute("captchaMsg", "验证码不正确！");
            return "site/login";
        }
        int daysExpired = 7;
        if(remember){
            daysExpired = 30;
        }
        Map<String, Object> map = userService.login(username, password, daysExpired);
        if(map.get("success") == "success"){
            Cookie cookieUsername = new Cookie("itcampusUsername", map.get("username").toString());
            cookieUsername.setPath(contextPath);
            cookieUsername.setMaxAge(daysExpired * 86400);
            response.addCookie(cookieUsername);
            Cookie cookieTicket = new Cookie("itcampusTicket", map.get("ticket").toString());
            cookieTicket.setPath(contextPath);
            cookieTicket.setMaxAge(daysExpired * 86400);
            response.addCookie(cookieTicket);
            return "redirect:/main";
        }else{
            model.addAttribute("usernameMsg", map.get("usernameMsg"));
            model.addAttribute("passwordMsg", map.get("passwordMsg"));
            model.addAttribute("alterError", map.get("alterError"));
            model.addAttribute("alterWarning", map.get("alterWarning"));
            return "site/login";
        }
    }

    /*退出登录*/
    @LoginRequired
    @RequestMapping(value = "/logout", method = RequestMethod.GET)
    public String logout(Model model,
                         @CookieValue("itcampusUsername") String username,
                         @CookieValue("itcampusTicket") String ticket) throws SQLException {
        Map<String, Object> map = userService.logout(username, ticket);
        if(map.get("success") == "success"){
            model.addAttribute("altersWarning", map.get("logoutMsg"));
            model.addAttribute("altersSuccess", "退出登录成功！");
            return "redirect:/login";
        }else{
            model.addAttribute("logoutDanger", "后台程序出错，退出失败！");
            return "/main";
        }
    }

    /*忘记密码*/
    @LoginExpired
    @RequestMapping(value = "/forget", method = RequestMethod.GET)
    public String getForgetPasswordPage(Model model){
        return "site/forget";
    }

    /*获取邮箱验证码*/
    @LoginExpired
    @ResponseBody
    @RequestMapping(value = "/getCaptchaEmail", method = RequestMethod.POST)
    public String getCaptchaEmail(@RequestParam("email") String email) throws IllegalAccessException {
        JsonResultMap jsonResultMap = new JsonResultMap();
        if(StringUtils.isEmpty(email) || StringUtils.isBlank(email)){
            throw new IllegalAccessException("非法获取邮箱验证码，邮箱为空");
        }
        /*判断邮箱格式*/
        if(!RegexValidateUtil.validateEmail(email)){
            jsonResultMap.setCode(500);
            jsonResultMap.setMsg("邮箱地址不合法！");
            return JSON.toJSONString(jsonResultMap);
        }
        /*判断邮箱是否注册*/
        User user = userService.checkUserByEmail(email);
        if(user == null){
            jsonResultMap.setCode(500);
            jsonResultMap.setMsg("该邮箱尚未注册！");
            return JSON.toJSONString(jsonResultMap);
        }
        /*发送邮箱验证码*/
        Map<String, Object> map = userService.sendCaptchaEmail(email);
        if(map.get("success") != null){
            jsonResultMap.setCode(200);
            jsonResultMap.setMsg("邮箱验证码已发送，请注意查收！");
        }else{
            jsonResultMap.setCode(500);
            jsonResultMap.setMsg("邮箱验证码发送失败！");
        }
        return JSON.toJSONString(jsonResultMap);
    }

    /*正式找回密码*/
    @LoginExpired
    @RequestMapping(value = "/forget", method = RequestMethod.POST)
    public String forgetPassword(Model model,
                                 @RequestParam("email") String email,
                                 @RequestParam("codeVerify") String codeVerify,
                                 @RequestParam("password") String password,
                                 @RequestParam("captcha") String captcha,
                                 @CookieValue(value = "ownerCaptchaForget", required = false) String ownerCaptchaForget) throws IllegalAccessException, SQLException {
        if(StringUtils.isEmpty(email) || StringUtils.isBlank(email)){
            throw new IllegalAccessException("非法找回密码，邮箱为空");
        }
        if(StringUtils.isEmpty(codeVerify) || StringUtils.isBlank(codeVerify)){
            throw new IllegalAccessException("非法找回密码，邮箱验证码为空");
        }
        if(StringUtils.isEmpty(password) || StringUtils.isBlank(password)){
            throw new IllegalAccessException("非法找回密码，新密码为空");
        }
        if(StringUtils.isEmpty(captcha) || StringUtils.isBlank(captcha)){
            throw new IllegalAccessException("非法找回密码，验证码为空");
        }
        /*如果客户端的Cookie已经过期，提示用户*/
        if(ownerCaptchaForget == null){
            model.addAttribute("alterWarning", "您的验证码已过期，请点击验证码图片更换一张！");
            return "site/forget";
        }
        /*判断参数是否正常*/
        if(!RegexValidateUtil.validateEmail(email)){
            model.addAttribute("emailMsg", "邮箱格式不合法！");
            return "site/forget";
        }
        if(!RegexValidateUtil.validatePwd(password)){
            model.addAttribute("passwordMsg", "密码规则（8-16位字母或数字）");
            return "site/forget";
        }
        /*判断验证码，不区分大小写*/
        if(StringUtils.isEmpty(ownerCaptchaForget) || StringUtils.isBlank(ownerCaptchaForget)){
            model.addAttribute("captchaMsg", "验证码已过期，请刷新！");
            return "site/forget";
        }
        String captchaKey = RedisKeyUtil.getCaptchaKey("forget", ownerCaptchaForget);
        String captchaRedis = (String) redisTemplate.opsForValue().get(captchaKey);
        if(captchaRedis == null){
            model.addAttribute("captchaMsg", "验证码已过期，请刷新！");
            return "site/forget";
        }
        if(!captchaRedis.equals(captcha.toUpperCase())){
            model.addAttribute("captchaMsg", "验证码不正确！");
            return "site/forget";
        }
        /*判断邮箱验证码是否正确*/
        String captchaEmailKey = RedisKeyUtil.getCaptchaEmailKey(email);
        String captchaEmail = (String) redisTemplate.opsForValue().get(captchaEmailKey);
        if(captchaEmail == null){
            model.addAttribute("codeVerifyMsg", "邮箱验证码已过期(或者您填写的邮箱已变动)！");
            return "site/forget";
        }
        if(!codeVerify.equals(captchaEmail)){
            model.addAttribute("codeVerifyMsg", "邮箱验证码不正确！");
            return "site/forget";
        }
        /*参数正确*/
        String random = SecurityUtil.generateUUID();
        String passwordEncrypt = SecurityUtil.encryptMD5(password + random);
        Integer num = userService.revisePasswordByEmail(email, passwordEncrypt, random);
        if(num != 1){
            throw new SQLException("修改密码失败，找回密码失败");
        }
        return "redirect:/login";
    }
}
