package com.itcampus.controller;

import com.alibaba.fastjson.JSON;
import com.itcampus.annotation.LoginRequired;
import com.itcampus.domain.Notice;
import com.itcampus.domain.Page;
import com.itcampus.domain.UserLogined;
import com.itcampus.event.ProducerEvent;
import com.itcampus.service.FollowService;
import com.itcampus.service.UserService;
import com.itcampus.utils.HostHolder;
import com.itcampus.utils.JsonResultMap;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping(value = "/follow")
public class FollowController {

    @Autowired
    private FollowService followService;

    @Autowired
    private UserService userService;

    @Autowired
    private HostHolder hostHolder;

    @Autowired
    private ProducerEvent producerEvent;

    @LoginRequired
    @ResponseBody
    @RequestMapping(value = "/addOrCancel", method = RequestMethod.POST)
    public String followAddOrCancel(@RequestParam("typeEntity") String typeEntity,
                                    @RequestParam("idEntity") Integer idEntity) throws IllegalAccessException {
        if(StringUtils.isEmpty(typeEntity) || StringUtils.isBlank(typeEntity)){
            throw new IllegalAccessException("非法关注或取消关注，关注对象类型为空");
        }
        if(idEntity == null){
            throw new IllegalAccessException("非法关注或取消关注，关注对象标识为空");
        }
        UserLogined userLogined = hostHolder.getUser();
        if(userLogined == null){
            throw new IllegalAccessException("非法关注或取消关注，当前线程没有找到登录用户");
        }
        JsonResultMap<Map<String, Object>> jsonResultMap = new JsonResultMap<>();
        Map<String, Object> map = followService.follow(userLogined.getId(), typeEntity, idEntity);
        jsonResultMap.setCode(200);
        jsonResultMap.setMsg("关注或取消关注成功！");
        jsonResultMap.setCount(1);
        jsonResultMap.setData(map);
        /*关注或取消关注都应该触发通知事件*/
        Notice notice = new Notice();
        notice.setIdUser(userLogined.getId());
        /*关注或取关事件类型固定*/
        notice.setTypeEvent("follow");
        /*关注或取关不需要设定事件id, 也不需要制定实体id，目标用户id就是实体id*/
        notice.setIdUserTarget(idEntity);
        notice.setTypeEntity(typeEntity);
        if(map.get("statusFollow") == "已关注" || map.get("statusFollow") == "已互粉"){
            notice.setContent("关注了你");
        }else{
            notice.setContent("取消关注你");
        }
        notice.setStatus("unread");
        notice.setTimeCreate(new Date());
        producerEvent.triggerEvent(notice);
        return JSON.toJSONString(jsonResultMap);
    }

    /*当前用户关注的用户列表*/
    @LoginRequired
    @RequestMapping(value = "/followee", method = RequestMethod.GET)
    public String followee(Model model,
                           @RequestParam(value = "pageIndex", required = false, defaultValue = "1") Integer pageIndex) throws IllegalAccessException {
        UserLogined userLogined = hostHolder.getUser();
        if(userLogined == null){
            throw new IllegalAccessException("非法访问关注列表，当前线程没有找到登录用户");
        }
        model.addAttribute("userLogined", userLogined);
        model.addAttribute("user", userLogined);
        Page page = new Page();
        page.setPageIndex(pageIndex);
        page.setPageSize(10);
        page.setDataRows((int) followService.checkCountFollowee(userLogined.getId(), "user"));
        page.setPath("/follow/followee");
        model.addAttribute("page", page);
        List<Map<String, Object>> list = followService.queryFollowee(userLogined.getId(), userLogined.getId(), page.getDataBegin() - 1, page.getPageSize());
        model.addAttribute("followeeList", list);
        return "site/followee";
    }

    /*访问别人关注的用户列表*/
    @RequestMapping(value = "/followee/{idUser}", method = RequestMethod.GET)
    public String followeeByIdUser(Model model,
                           @PathVariable("idUser") Integer idUser,
                           @RequestParam(value = "pageIndex", required = false, defaultValue = "1") Integer pageIndex) throws IllegalAccessException {
        if(idUser == null){
            throw new IllegalAccessException("非法访问关注列表，关注者的标识为空");
        }
        UserLogined userLogined = hostHolder.getUser();
        model.addAttribute("userLogined", userLogined);
        UserLogined user = userService.checkUserLoginedById(idUser);
        model.addAttribute("user", user);
        Page page = new Page();
        page.setPageIndex(pageIndex);
        page.setPageSize(10);
        page.setDataRows((int) followService.checkCountFollowee(idUser, "user"));
        page.setPath("/follow/followee/" + idUser);
        model.addAttribute("page", page);
        List<Map<String, Object>> list = followService.queryFollowee(userLogined!=null?userLogined.getId():null, idUser, page.getDataBegin() - 1, page.getPageSize());
        model.addAttribute("followeeList", list);
        return "site/followee";
    }

    /*当前用户的粉丝用户列表*/
    @LoginRequired
    @RequestMapping(value = "/follower", method = RequestMethod.GET)
    public String follower(Model model,
                           @RequestParam(value = "pageIndex", required = false, defaultValue = "1") Integer pageIndex) throws IllegalAccessException {
        UserLogined userLogined = hostHolder.getUser();
        if(userLogined == null){
            throw new IllegalAccessException("非法访问粉丝列表，当前线程没有找到登录用户");
        }
        model.addAttribute("userLogined", userLogined);
        model.addAttribute("user", userLogined);
        Page page = new Page();
        page.setPageIndex(pageIndex);
        page.setPageSize(10);
        page.setDataRows((int) followService.checkCountFollower("user", userLogined.getId()));
        page.setPath("/follow/follower");
        model.addAttribute("page", page);
        List<Map<String, Object>> list = followService.queryFollower(userLogined.getId(), userLogined.getId(), page.getDataBegin() - 1, page.getPageSize());
        model.addAttribute("followerList", list);
        return "site/follower";
    }

    /*访问别人的粉丝用户列表*/
    @RequestMapping(value = "/follower/{idUser}", method = RequestMethod.GET)
    public String followerByIdUser(Model model,
                           @PathVariable("idUser") Integer idUser,
                           @RequestParam(value = "pageIndex", required = false, defaultValue = "1") Integer pageIndex) throws IllegalAccessException {
        if(idUser == null){
            throw new IllegalAccessException("非法访问粉丝列表，被关注者的标识为空");
        }
        UserLogined userLogined = hostHolder.getUser();
        model.addAttribute("userLogined", userLogined);
        UserLogined user = userService.checkUserLoginedById(idUser);
        model.addAttribute("user", user);
        Page page = new Page();
        page.setPageIndex(pageIndex);
        page.setPageSize(10);
        page.setDataRows((int) followService.checkCountFollower("user", idUser));
        page.setPath("/follow/follower/" + idUser);
        model.addAttribute("page", page);
        List<Map<String, Object>> list = followService.queryFollower(userLogined!=null?userLogined.getId():null, idUser, page.getDataBegin() - 1, page.getPageSize());
        model.addAttribute("followerList", list);
        return "site/follower";
    }
}
