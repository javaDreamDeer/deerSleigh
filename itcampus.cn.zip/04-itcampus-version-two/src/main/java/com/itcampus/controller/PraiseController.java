package com.itcampus.controller;

import com.alibaba.fastjson.JSON;
import com.itcampus.annotation.LoginRequired;
import com.itcampus.domain.Notice;
import com.itcampus.domain.UserLogined;
import com.itcampus.event.ProducerEvent;
import com.itcampus.service.PraiseService;
import com.itcampus.utils.HostHolder;
import com.itcampus.utils.JsonResultMap;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Date;
import java.util.Map;

@Controller
@RequestMapping(value = "/praise")
public class PraiseController {

    @Autowired
    private PraiseService praiseService;

    @Autowired
    private ProducerEvent producerEvent;

    @Autowired
    private HostHolder hostHolder;

    @LoginRequired
    @ResponseBody
    @RequestMapping(value = "/addOrReduce", method = RequestMethod.POST)
    public String addOrReducePraise(@RequestParam("typeEntity") String typeEntity,
                                    @RequestParam("idEntity") Integer idEntity,
                                    @RequestParam("idUserEntity") Integer idUserEntity) throws IllegalAccessException {
        if(StringUtils.isEmpty(typeEntity) || StringUtils.isBlank(typeEntity)){
            throw new IllegalAccessException("非法点赞，点赞对象的类型为空");
        }
        if(idEntity == null){
            throw new IllegalAccessException("非法点赞，点赞对象的标识为空");
        }
        if(idUserEntity == null){
            throw new IllegalAccessException("非法点赞，点赞对象所属用户的标识为空");
        }
        UserLogined userLogined = hostHolder.getUser();
        if(userLogined == null){
            throw new IllegalAccessException("非法访问，当前线程找不到登录用户");
        }
        Map<String, Object> map = praiseService.increaseOrDecreasePraise(userLogined.getId(), typeEntity, idEntity, idUserEntity);
        JsonResultMap<Map<String, Object>> jsonResultMap = new JsonResultMap<>();
        jsonResultMap.setCode(200);
        jsonResultMap.setMsg("点赞或取消点赞成功！");
        jsonResultMap.setCount(1);
        jsonResultMap.setData(map);
        /*如果是点赞，触发通知事件*/
        /*如果自己给自己点赞，没有必要通知事件*/
        if(idUserEntity.equals(userLogined.getId())){
            return JSON.toJSONString(jsonResultMap);
        }
        if(map.get("statusPraise") == "已赞"){
            Notice notice = new Notice();
            notice.setIdUser(userLogined.getId());
            /*点赞事件类型固定*/
            notice.setTypeEvent("praise");
            /*点赞不需要设定事件id，因为点赞本身不是一个实体*/
            notice.setIdEntity(idEntity);
            notice.setIdUserTarget(idUserEntity);
            /*点赞需要指定实体类型，用于区分给什么实体点了赞，以便指定实体url*/
            notice.setTypeEntity(typeEntity);
            notice.setContent("给你点了个赞");
            notice.setStatus("unread");
            notice.setTimeCreate(new Date());
            producerEvent.triggerEvent(notice);
        }
        return JSON.toJSONString(jsonResultMap);
    }
}
