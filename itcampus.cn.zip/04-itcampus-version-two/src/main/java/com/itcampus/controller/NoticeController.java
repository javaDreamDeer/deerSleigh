package com.itcampus.controller;

import com.alibaba.fastjson.JSON;
import com.itcampus.annotation.LoginRequired;
import com.itcampus.domain.Notice;
import com.itcampus.domain.Page;
import com.itcampus.domain.UserLogined;
import com.itcampus.service.NoticeService;
import com.itcampus.utils.HostHolder;
import com.itcampus.utils.JsonResultMap;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping(value = "/message")
public class NoticeController {

    @Autowired
    private NoticeService noticeService;

    @Autowired
    private HostHolder hostHolder;

    @LoginRequired
    @RequestMapping(value = "/notice", method = RequestMethod.GET)
    public String messageNotice(Model model) throws IllegalAccessException {
        UserLogined userLogined = hostHolder.getUser();
        if(userLogined == null){
            throw new IllegalAccessException("非法查看系统通知，当前线程找不到登录用户");
        }
        Map<String, Object> map = noticeService.checkNoticeTotal(userLogined.getId());
        model.addAttribute("map", map);
        return "site/notice";
    }

    @LoginRequired
    @RequestMapping(value = "/notice/{typeEvent}", method = RequestMethod.GET)
    public String messageNoticeTypeEntity(Model model,
                                          @PathVariable("typeEvent") String typeEvent,
                                          @RequestParam(value = "pageIndex", required = false, defaultValue = "1") Integer pageIndex) throws IllegalAccessException, SQLException {
        if(StringUtils.isEmpty(typeEvent) || StringUtils.isBlank(typeEvent)){
            throw new IllegalAccessException("非法查看通知详情，通知类型为空");
        }
        UserLogined userLogined = hostHolder.getUser();
        if(userLogined == null){
            throw new IllegalAccessException("非法查看通知详情，当前线程找不到登录用户");
        }
        Page page = new Page();
        page.setPageIndex(pageIndex);
        page.setPageSize(10);
        page.setPath("/message/notice/" + typeEvent);
        page.setDataRows(noticeService.checkCountByTypeEvent(userLogined.getId(), typeEvent));
        model.addAttribute("page", page);
        Map<String, Object> map = noticeService.queryNoticeTypeEvent(userLogined.getId(), typeEvent, page.getPageIndex(), page.getPageSize());
        model.addAttribute("map", map);
        model.addAttribute("typeEventCurrent", typeEvent);
        return "site/notice-detail";
    }

    @LoginRequired
    @ResponseBody
    @RequestMapping(value = "/notice/reduce", method = RequestMethod.POST)
    public String messageNoticeReduce(@RequestParam("idNotice") Integer idNotice) throws IllegalAccessException, SQLException {
        if(idNotice == null){
            throw new IllegalAccessException("非法删除通知，通知标识为空");
        }
        UserLogined userLogined = hostHolder.getUser();
        if(userLogined == null){
            throw new IllegalAccessException("非法删除通知，当前线程找不到登录用户");
        }
        JsonResultMap jsonResultMap = new JsonResultMap();
        Integer num = noticeService.decreaseById(idNotice);
        if(num != 1){
            throw new SQLException("删除通知事件失败");
        }
        jsonResultMap.setCode(200);
        jsonResultMap.setMsg("删除成功！");
        return JSON.toJSONString(jsonResultMap);
    }

    @LoginRequired
    @ResponseBody
    @RequestMapping(value = "/notice/empty", method = RequestMethod.POST)
    public String messageNoticeEmpty(@RequestParam("typeEvent") String typeEvent) throws IllegalAccessException, SQLException {
        if(StringUtils.isEmpty(typeEvent) || StringUtils.isBlank(typeEvent)){
            throw new IllegalAccessException("非法清空通知，通知事件类型为空");
        }
        UserLogined userLogined = hostHolder.getUser();
        if(userLogined == null){
            throw new IllegalAccessException("非法清空通知，当前线程找不到登录用户");
        }
        JsonResultMap jsonResultMap = new JsonResultMap();
        Map<String, Object> map = noticeService.decreaseListByTypeEvent(userLogined.getId(), typeEvent);
        if(map.get("success") != null){
            jsonResultMap.setCode(200);
            jsonResultMap.setMsg("清空通知成功！");
        }else{
            jsonResultMap.setCode(500);
            jsonResultMap.setMsg("清空通知失败！");
        }
        return JSON.toJSONString(jsonResultMap);
    }
}
