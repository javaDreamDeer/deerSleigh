package com.itcampus.controller;

import com.itcampus.domain.Page;
import com.itcampus.domain.Statement;
import com.itcampus.domain.User;
import com.itcampus.domain.UserLogined;
import com.itcampus.service.*;
import com.itcampus.utils.HostHolder;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class HomeController {

    @Autowired
    private UserService userService;

    @Autowired
    private StatementService statementService;

    @Autowired
    private MessageService messageService;

    @Autowired
    private PraiseService praiseService;

    @Autowired
    private NoticeService noticeService;

    @Autowired
    private HostHolder hostHolder;

    @RequestMapping(value = {"","/main"}, method = RequestMethod.GET)
    public String getIndexPageAndCommunications(Model model,
                                                @RequestParam(value = "pageIndex", required=false, defaultValue="1") String pageIndex){
        int index = Integer.parseInt(pageIndex);
        Page page = new Page();
        page.setPageIndex(index);
        page.setDataRows(statementService.checkStatementCount());
        page.setPath("/main");
        List<Statement> statementList = statementService.queryStatementList(page.getPageIndex(), page.getPageSize());
        List<Map<String, Object>> mapList = new ArrayList<>();
        List<Map<String, Object>> officialList = new ArrayList<>();
        if(statementList != null){
            for(Statement statement : statementList){
                Map<String, Object> map = new HashMap<>();
                Map<String, Object> mapOfficial = new HashMap<>();
                long countPraise = praiseService.checkCountPraiseEntity("statement", statement.getId());
                statement.setCountPraise((int) countPraise);
                map.put("statement", statement);
                UserLogined user = userService.checkUserLoginedById(statement.getIdUser());
                map.put("user", user);
                if("official".equals(statement.getType())){
                    officialList.add(map);
                }else{
                    mapList.add(map);
                }
            }
        }
        model.addAttribute("discussionList", mapList);
        model.addAttribute("discussionOfficialList", officialList);
        model.addAttribute("page", page);
        /*如果用户已登录，查询未读消息*/
        UserLogined userLogined = hostHolder.getUser();
        if(userLogined != null){
            Integer letterUnreadCountTotal = messageService.checkLetterUnreadCount(userLogined.getId());
            Integer noticeUnreadCountTotal = noticeService.checkUnreadCount(userLogined.getId(), "unread");
            model.addAttribute("countTotalUnreadMessage", letterUnreadCountTotal + noticeUnreadCountTotal);
            /*如果用户是警告状态，不能发布公开信息*/
            if("warning".equals(userLogined.getConditions())){
                model.addAttribute("alterWarning", "您当前的账号为警告状态！不能发布公开信息！");
            }
        }
        return "index";
    }

}
