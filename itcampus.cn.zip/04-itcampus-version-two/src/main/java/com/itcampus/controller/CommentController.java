package com.itcampus.controller;

import com.alibaba.fastjson.JSON;
import com.itcampus.annotation.LoginRequired;
import com.itcampus.domain.Comment;
import com.itcampus.domain.Notice;
import com.itcampus.domain.Statement;
import com.itcampus.domain.UserLogined;
import com.itcampus.event.ProducerEvent;
import com.itcampus.service.CommentService;
import com.itcampus.service.StatementService;
import com.itcampus.utils.HostHolder;
import com.itcampus.utils.JsonResultMap;
import com.itcampus.utils.SensitiveFilter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.HtmlUtils;

import java.sql.SQLException;
import java.util.Date;
import java.util.Map;

@Controller
@RequestMapping(value = "/comment")
public class CommentController {

    @Autowired
    private CommentService commentService;

    @Autowired
    private StatementService statementService;

    @Autowired
    private HostHolder hostHolder;

    @Autowired
    private SensitiveFilter sensitiveFilter;

    @Autowired
    private ProducerEvent producerEvent;

    @LoginRequired
    @RequestMapping(value = "/add/{idStatement}", method = RequestMethod.POST)
    public String addCommentByIdStatement(Model model,
                                          @PathVariable("idStatement") Integer idStatement,
                                          @RequestParam("typeEntity") String typeEntity,
                                          @RequestParam("idEntity") Integer idEntity,
                                          @RequestParam(value = "idTarget", required = false, defaultValue = "0") Integer idTarget,
                                          @RequestParam("content") String content,
                                          @RequestParam(value = "pageIndex", required = false, defaultValue = "1") Integer pageIndex) throws IllegalAccessException, SQLException {
        if(idStatement == null){
            throw new IllegalAccessException("非法增添评论，发布贴的id为空");
        }
        if(StringUtils.isEmpty(typeEntity) || StringUtils.isBlank(typeEntity)){
            throw new IllegalAccessException("非法增添评论，实体类型为空");
        }
        if(idEntity == null){
            throw new IllegalAccessException("非法增添评论，实体id为空");
        }
        UserLogined userLogined = hostHolder.getUser();
        if(userLogined == null){
            throw new IllegalAccessException("非法增添评论，当前线程找不到登录用户信息");
        }
        /*检查用户有没有评论权限*/
        if("warning".equals(userLogined.getConditions())){
            model.addAttribute("alterWarning", "您当前的账号为警告状态！不能发表公开信息！");
            return "redirect:/statement/detail/" + idStatement + "?pageIndex=" + pageIndex;
        }
        if(StringUtils.isEmpty(content) || StringUtils.isBlank(content)){
            model.addAttribute("alterError", "评论或回复不能为空！");
            return "redirect:/statement/detail/" + idStatement + "?pageIndex=" + pageIndex;
        }
        Comment comment = new Comment();
        comment.setIdUser(userLogined.getId());
        comment.setTypeEntity(typeEntity);
        comment.setIdEntity(idEntity);
        comment.setIdTarget(idTarget);
        content = HtmlUtils.htmlEscape(content);
        content = sensitiveFilter.filter(content);
        comment.setContent(content);
        comment.setStatus("normal");
        comment.setTimeCreate(new Date());
        Map<String, Object> map = commentService.increaseComment(comment);
        if(map.get("success") != null){
            model.addAttribute("alterSuccess", "发表评论成功！");
        }else{
            model.addAttribute("alterError", "发表评论失败！");
        }
        /*触发通知事件*/
        /*如果是自己评论自己，自己回复自己，没有必要通知事件*/
        if("comment".equals(typeEntity)){
            Statement statementTest = statementService.checkById(idEntity);
            if(userLogined.getId().equals(statementTest.getIdUser())){
                return "redirect:/statement/detail/" + idStatement + "?pageIndex=" + pageIndex;
            }
        }else{
            Comment commentTest = commentService.checkById(idEntity);
            if(userLogined.getId().equals(commentTest.getIdUser())){
                return "redirect:/statement/detail/" + idStatement + "?pageIndex=" + pageIndex;
            }else{
                if(idTarget != 0 && idTarget.equals(userLogined.getId())){
                    return "redirect:/statement/detail/" + idStatement + "?pageIndex=" + pageIndex;
                }
            }
        }
        Notice notice = new Notice();
        /*谁触发的事件*/
        notice.setIdUser(comment.getIdUser());
        /*事件类型*/
        notice.setTypeEvent(comment.getTypeEntity());
        /*事件id*/
        notice.setIdEvent(comment.getId());
        /*对哪个实体触发事件*/
        notice.setIdEntity(comment.getIdEntity());
        /*事件要发给谁*/
        if(idTarget == 0){
            /*非回复型评论，IdUserTarget是IdUserEntity*/
            if("comment".equals(notice.getTypeEvent())){
                notice.setIdUserTarget(statementService.checkById(notice.getIdEntity()).getIdUser());
            }else{
                notice.setIdUserTarget(commentService.checkById(notice.getIdEntity()).getIdUser());
            }
            /*事件rul地址不设定，直接设定事件内容*/
            notice.setContent("评论了你");
        }else{
            /*回复型评论，IdUserTarget就是idTarget*/
            notice.setIdUserTarget(idTarget);
            /*目标用户查看事件时再生成事件url地址*/
            notice.setContent("回复了你");
        }
        /*评论不用指定实体类型，凭借TypeEvent的不同即可锁定实体url*/
        /*通知状态，初始未读*/
        notice.setStatus("unread");
        /*事件触发时间*/
        notice.setTimeCreate(new Date());
        /*把事件添加在消息队列*/
        producerEvent.triggerEvent(notice);
        return "redirect:/statement/detail/" + idStatement + "?pageIndex=" + pageIndex;
    }

    @LoginRequired
    @ResponseBody
    @RequestMapping(value = "/reduce", method = RequestMethod.POST)
    public String commentReduce(@RequestParam("idEntity") Integer idEntity) throws IllegalAccessException, SQLException {
        if(idEntity == null){
            throw new IllegalAccessException("非法删除评论，评论标识为空");
        }
        UserLogined userLogined = hostHolder.getUser();
        if(userLogined == null){
            throw new IllegalAccessException("非法删除评论，当前线程找不到登录用户");
        }
        Comment comment = commentService.checkById(idEntity);
        if(!userLogined.getId().equals(comment.getIdUser())){
            throw new IllegalAccessException("非法删除评论，登录用户只能删除自己的评论");
        }
        JsonResultMap jsonResultMap = new JsonResultMap();
        Integer num = commentService.reviseStatusById(idEntity, "deleted");
        if(num != 1){
            throw new SQLException("删除评论失败");
        }
        jsonResultMap.setCode(200);
        jsonResultMap.setMsg("删除成功！");
        return JSON.toJSONString(jsonResultMap);
    }

    @LoginRequired
    @ResponseBody
    @RequestMapping(value = "/illegality", method = RequestMethod.POST)
    public String commentIllegality(@RequestParam("idEntity") Integer idEntity) throws IllegalAccessException, SQLException {
        if(idEntity == null){
            throw new IllegalAccessException("非法拉黑评论，评论标识为空");
        }
        UserLogined userLogined = hostHolder.getUser();
        if(userLogined == null){
            throw new IllegalAccessException("非法拉黑评论，当前线程找不到登录用户");
        }
        Comment comment = commentService.checkById(idEntity);
        if("comment".equals(comment.getTypeEntity())){
            Statement statement = statementService.checkById(comment.getIdEntity());
            if(!userLogined.getId().equals(statement.getIdUser())){
                throw new IllegalAccessException("非法拉黑评论，当前登录用户没有此权限");
            }
        }else{
            Comment commentTarget = commentService.checkById(comment.getIdEntity());
            if(!userLogined.getId().equals(commentTarget.getIdUser())){
                throw new IllegalAccessException("非法拉黑评论，当前登录用户没有此权限");
            }
        }
        JsonResultMap jsonResultMap = new JsonResultMap();
        Integer num = commentService.reviseStatusById(idEntity, "illegal");
        if(num != 1){
            throw new SQLException("拉黑评论失败");
        }
        jsonResultMap.setCode(200);
        jsonResultMap.setMsg("拉黑成功！");
        /*触发警告通知事件，事件不区分评论和回复*/
        Notice notice = new Notice();
        notice.setIdUser(userLogined.getId());
        notice.setTypeEvent("illegality");
        notice.setIdEvent(idEntity);
        /*不需要指定idEntity*/
        /*typeEntity统一设定为评论*/
        notice.setTypeEntity("comment");
        notice.setIdUserTarget(comment.getIdUser());
        notice.setContent("拉黑了你的评论或回复");
        notice.setStatus("unread");
        notice.setTimeCreate(new Date());
        producerEvent.triggerEvent(notice);
        return JSON.toJSONString(jsonResultMap);
    }

    @LoginRequired
    @ResponseBody
    @RequestMapping(value = "/top", method = RequestMethod.POST)
    public String commentTop(@RequestParam("idEntity") Integer idEntity) throws IllegalAccessException, SQLException {
        if(idEntity == null){
            throw new IllegalAccessException("非法顶置评论，评论标识为空");
        }
        UserLogined userLogined = hostHolder.getUser();
        if(userLogined == null){
            throw new IllegalAccessException("非法顶置评论，当前线程找不到登录用户");
        }
        Comment comment = commentService.checkById(idEntity);
        Statement statement = statementService.checkById(comment.getIdEntity());
        if(!userLogined.getId().equals(statement.getIdUser())){
            throw new IllegalAccessException("非法顶置评论，当前登录用户没有权限");
        }
        JsonResultMap jsonResultMap = new JsonResultMap();
        if("top".equals(comment.getStatus())){
            jsonResultMap.setCode(500);
            jsonResultMap.setMsg("已经设置为顶置！");
            return JSON.toJSONString(jsonResultMap);
        }
        Integer num = commentService.reviseStatusById(idEntity, "top");
        if(num != 1){
            throw new SQLException("顶置评论失败");
        }
        jsonResultMap.setCode(200);
        jsonResultMap.setMsg("顶置成功！");
        /*触发善意通知事件*/
        if(!userLogined.getId().equals(comment.getIdUser())){
            Notice notice = new Notice();
            notice.setIdUser(userLogined.getId());
            notice.setTypeEvent("goodwill");
            notice.setIdEvent(idEntity);
            /*因为可以直接设置urlEntity，所以可以不设置idEntity*/
            notice.setTypeEntity("comment");
            notice.setUrlEntity("/statement/detail/"+statement.getId());
            notice.setIdUserTarget(commentService.checkById(idEntity).getIdUser());
            notice.setContent("顶置了你的评论");
            notice.setStatus("unread");
            notice.setTimeCreate(new Date());
            producerEvent.triggerEvent(notice);
        }
        return JSON.toJSONString(jsonResultMap);
    }
}
