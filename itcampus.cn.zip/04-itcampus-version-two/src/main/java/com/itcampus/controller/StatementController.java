package com.itcampus.controller;

import com.alibaba.fastjson.JSON;
import com.itcampus.annotation.LoginRequired;
import com.itcampus.domain.*;
import com.itcampus.event.ProducerEvent;
import com.itcampus.service.CommentService;
import com.itcampus.service.StatementService;
import com.itcampus.service.UserService;
import com.itcampus.utils.HostHolder;
import com.itcampus.utils.JsonResultMap;
import com.itcampus.utils.RedisKeyUtil;
import com.itcampus.utils.SensitiveFilter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.HtmlUtils;

import java.sql.SQLException;
import java.util.Date;
import java.util.Map;
import java.util.Set;

@Controller
@RequestMapping(value = "/statement")
public class StatementController {

    @Autowired
    private StatementService statementService;

    @Autowired
    private CommentService commentService;

    @Autowired
    private UserService userService;

    @Autowired
    private HostHolder hostHolder;

    @Autowired
    private SensitiveFilter sensitiveFilter;

    @Autowired
    private RedisTemplate redisTemplate;

    @Autowired
    private ProducerEvent producerEvent;

    @LoginRequired
    @ResponseBody
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public String addStatement(@RequestParam("title") String title,
                               @RequestParam("content") String content) throws IllegalAccessException, SQLException {
        UserLogined userLogined = hostHolder.getUser();
        if(userLogined == null){
            throw new IllegalAccessException("非法发布，当前线程找不到用户信息");
        }
        JsonResultMap jsonResult = new JsonResultMap();
        /*判断当前用户有没有发布权限*/
        if("warning".equals(userLogined.getConditions())){
            jsonResult.setCode(500);
            jsonResult.setMsg("您当前账号为警告状态！不能发布公开信息！");
            return JSON.toJSONString(jsonResult);
        }
        if(StringUtils.isEmpty(title) || StringUtils.isBlank(title)){
            jsonResult.setCode(500);
            jsonResult.setMsg("发布标题不能为空！");
            jsonResult.setCount(0);
            return JSON.toJSONString(jsonResult);
        }
        if(StringUtils.isEmpty(content) || StringUtils.isBlank(content)){
            jsonResult.setCode(500);
            jsonResult.setMsg("发布内容不能为空！");
            jsonResult.setCount(0);
            return JSON.toJSONString(jsonResult);
        }
        // 转义HTML标记
        title = HtmlUtils.htmlEscape(title);
        content = HtmlUtils.htmlEscape(content);
        // 过滤敏感词
        title = sensitiveFilter.filter(title);
        content = sensitiveFilter.filter(content);
        /*定义实体参数在Controller层，方便使用插入后返回的实体id*/
        Statement statement = new Statement();
        statement.setIdUser(userLogined.getId());
        statement.setTitle(title);
        statement.setContent(content);
        statement.setType("general");
        statement.setStatus("normal");
        statement.setTimeCreate(new Date());
        statement.setCountPraise(0);
        statement.setCountComment(0);
        statement.setScore(0.0);
        Map<String, Object> map = statementService.increaseStatement(statement);
        if(map.get("success") != null){
            jsonResult.setCode(200);
            jsonResult.setMsg("发布成功！");
            jsonResult.setCount(0);
        }else{
            jsonResult.setCode(500);
            jsonResult.setMsg("发布失败！");
            jsonResult.setCount(0);
        }
        /*触发善意通知事件，通知当前用户的粉丝*/
        Notice notice = new Notice();
        notice.setIdUser(userLogined.getId());
        notice.setTypeEvent("goodwill");
        notice.setIdEvent(statement.getId());
        /*通知发布事件不需要指定idEntity*/
        /*指定typeEntity*/
        notice.setTypeEntity("statement");
        /*urlEntity可以直接指定*/
        notice.setUrlEntity("/statement/detail/"+notice.getIdEvent());
        notice.setContent("发布新帖啦");
        notice.setStatus("unread");
        notice.setTimeCreate(new Date());
        /*通知给当前用户所有粉丝，所以要循环指定idUserTarget*/
        String followerKey = RedisKeyUtil.getFollowerKey("user", userLogined.getId());
        Set<Integer> idUserSet = redisTemplate.opsForZSet().range(followerKey, 0, -1);
        if(idUserSet != null){
            for (Integer idUser : idUserSet){
                notice.setIdUserTarget(idUser);
                producerEvent.triggerEvent(notice);
            }
        }
        return JSON.toJSONString(jsonResult);
    }

    @RequestMapping(value = "/detail/{id}", method = RequestMethod.GET)
    public String readStatementById(Model model,
                                    @PathVariable("id") Integer id,
                                    @RequestParam(value = "pageIndex", required=false, defaultValue="1") Integer pageIndex) throws IllegalAccessException, SQLException {
        if(id == null){
            throw new IllegalAccessException("非法查看发布详情，发布标识为空");
        }
        Statement statement = statementService.checkById(id);
        if("deleted".equals(statement.getStatus()) || "illegal".equals(statement.getStatus())){
            model.addAttribute("titleTips", "访问无效");
            model.addAttribute("contentTips","该发布已被删除或被管理员拉黑！");
            return "site/operate-tips";
        }
        Page page = new Page();
        page.setPageIndex(pageIndex);
        page.setPageSize(5);
        page.setDataRows(commentService.checkCommentCountByIdEntityTypeEntity(id, "comment"));
        page.setPath("/statement/detail/" + id);
        model.addAttribute("page", page);
        UserLogined userLogined = hostHolder.getUser();
        model.addAttribute("userLogined", userLogined);
        Map<String, Object> map = statementService.checkStatementById(userLogined!=null?userLogined.getId():null, id, page.getPageIndex(), page.getPageSize(), page.getDataRows());
        model.addAttribute("map", map);
        return "site/discuss-detail";
    }

    @LoginRequired
    @ResponseBody
    @RequestMapping(value = "/reduce", method = RequestMethod.POST)
    public String statementReduce(@RequestParam("idEntity") Integer idEntity) throws IllegalAccessException, SQLException {
        if(idEntity == null){
            throw new IllegalAccessException("非法删除发布贴，发布标识为空");
        }
        UserLogined userLogined = hostHolder.getUser();
        if(userLogined == null){
            throw new IllegalAccessException("非法删除发布贴，当前线程找不到登录用户");
        }
        Statement statement = statementService.checkById(idEntity);
        if(!userLogined.getId().equals(statement.getIdUser())){
            throw new IllegalAccessException("非法删除发布贴，登录用户只能删除自己的发布贴");
        }
        JsonResultMap jsonResultMap = new JsonResultMap();
        Integer num = statementService.reviseStatusById(idEntity, "deleted");
        if(num != 1){
            throw new SQLException("删除发布贴失败");
        }
        jsonResultMap.setCode(200);
        jsonResultMap.setMsg("删除成功！");
        return JSON.toJSONString(jsonResultMap);
    }

    @LoginRequired
    @ResponseBody
    @RequestMapping(value = "/illegality", method = RequestMethod.POST)
    public String statementIllegality(@RequestParam("idEntity") Integer idEntity) throws IllegalAccessException, SQLException {
        if(idEntity == null){
            throw new IllegalAccessException("非法拉黑发布贴，发布标识为空");
        }
        UserLogined userLogined = hostHolder.getUser();
        if(userLogined == null){
            throw new IllegalAccessException("非法拉黑发布贴，当前线程找不到登录用户");
        }else{
            if(!"admin".equals(userLogined.getIdentity())){
                throw new IllegalAccessException("非法拉黑发布贴，当前登录用户不是管理员");
            }
            JsonResultMap jsonResultMap = new JsonResultMap();
            Integer num = statementService.reviseStatusById(idEntity, "illegal");
            if(num != 1){
                throw new SQLException("拉黑发布贴失败");
            }
            jsonResultMap.setCode(200);
            jsonResultMap.setMsg("拉黑成功！");
            /*触发警告通知事件*/
            Notice notice = new Notice();
            notice.setIdUser(userLogined.getId());
            notice.setTypeEvent("illegality");
            notice.setIdEvent(idEntity);
            /*也不需要设定idEntity*/
            notice.setTypeEntity("statement");
            notice.setIdUserTarget(statementService.checkById(idEntity).getIdUser());
            notice.setContent("拉黑了你的发布贴");
            notice.setStatus("unread");
            notice.setTimeCreate(new Date());
            producerEvent.triggerEvent(notice);
            return JSON.toJSONString(jsonResultMap);
        }
    }

    @LoginRequired
    @ResponseBody
    @RequestMapping(value = "/excellent", method = RequestMethod.POST)
    public String statementExcellent(@RequestParam("idEntity") Integer idEntity) throws IllegalAccessException, SQLException {
        if(idEntity == null){
            throw new IllegalAccessException("非法设置精华发布贴，发布标识为空");
        }
        UserLogined userLogined = hostHolder.getUser();
        if(userLogined == null){
            throw new IllegalAccessException("非法设置精华发布贴，当前线程找不到登录用户");
        }else{
            if(!"admin".equals(userLogined.getIdentity())){
                throw new IllegalAccessException("非法设置精华发布贴，当前登录用户不是管理员");
            }
            JsonResultMap jsonResultMap = new JsonResultMap();
            /*判断是否已经设置为精华*/
            Statement statement = statementService.checkById(idEntity);
            if("excellent".equals(statement.getStatus())){
                jsonResultMap.setCode(500);
                jsonResultMap.setMsg("已经设置为精华！");
                return JSON.toJSONString(jsonResultMap);
            }
            Integer num = statementService.reviseStatusById(idEntity, "excellent");
            if(num != 1){
                throw new SQLException("设置精华发布贴失败");
            }
            jsonResultMap.setCode(200);
            jsonResultMap.setMsg("设置精华成功！");
            /*触发善意通知事件*/
            /*如果是自己的发布贴，没有必要通知*/
            if(!userLogined.getId().equals(statement.getIdUser())){
                Notice notice = new Notice();
                notice.setIdUser(userLogined.getId());
                notice.setTypeEvent("goodwill");
                notice.setIdEvent(idEntity);
                /*类型为statement的善意通知不需要设定idEntity*/
                notice.setTypeEntity("statement");
                notice.setUrlEntity("/statement/detail/"+idEntity);
                notice.setIdUserTarget(statementService.checkById(idEntity).getIdUser());
                notice.setContent("加精了你的发布贴");
                notice.setStatus("unread");
                notice.setTimeCreate(new Date());
                producerEvent.triggerEvent(notice);
            }
            return JSON.toJSONString(jsonResultMap);
        }
    }

    @LoginRequired
    @ResponseBody
    @RequestMapping(value = "/official", method = RequestMethod.POST)
    public String statementOfficial(@RequestParam("idEntity") Integer idEntity) throws IllegalAccessException, SQLException {
        if(idEntity == null){
            throw new IllegalAccessException("非法顶置发布贴，发布标识为空");
        }
        UserLogined userLogined = hostHolder.getUser();
        if(userLogined == null){
            throw new IllegalAccessException("非法顶置发布贴，当前线程找不到登录用户");
        }else{
            if(!"admin".equals(userLogined.getIdentity())){
                throw new IllegalAccessException("非法顶置发布贴，当前登录用户不是管理员");
            }
            JsonResultMap jsonResultMap = new JsonResultMap();
            /*判断是否已经顶置*/
            Statement statement = statementService.checkById(idEntity);
            if("official".equals(statement.getType())){
                jsonResultMap.setCode(500);
                jsonResultMap.setMsg("已经设置为顶置！");
                return JSON.toJSONString(jsonResultMap);
            }
            Integer num = statementService.reviseTypeById(idEntity, "official");
            if(num != 1){
                throw new SQLException("顶置发布贴失败");
            }
            jsonResultMap.setCode(200);
            jsonResultMap.setMsg("顶置成功！");
            /*触发善意通知事件*/
            if(!userLogined.getId().equals(statement.getIdUser())){
                Notice notice = new Notice();
                notice.setIdUser(userLogined.getId());
                notice.setTypeEvent("goodwill");
                notice.setIdEvent(idEntity);
                /*不设置idEntity*/
                notice.setTypeEntity("statement");
                notice.setUrlEntity("/statement/detail/"+idEntity);
                notice.setIdUserTarget(statementService.checkById(idEntity).getIdUser());
                notice.setContent("顶置了你的发布贴");
                notice.setStatus("unread");
                notice.setTimeCreate(new Date());
                producerEvent.triggerEvent(notice);
            }
            return JSON.toJSONString(jsonResultMap);
        }
    }

}
