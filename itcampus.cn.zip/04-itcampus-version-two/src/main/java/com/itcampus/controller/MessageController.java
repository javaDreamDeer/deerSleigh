package com.itcampus.controller;

import com.alibaba.fastjson.JSON;
import com.itcampus.annotation.LoginRequired;
import com.itcampus.domain.Message;
import com.itcampus.domain.Page;
import com.itcampus.domain.User;
import com.itcampus.domain.UserLogined;
import com.itcampus.service.MessageService;
import com.itcampus.service.UserService;
import com.itcampus.utils.HostHolder;
import com.itcampus.utils.JsonResultMap;
import com.itcampus.utils.SensitiveFilter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.HtmlUtils;

import java.sql.SQLException;
import java.util.Date;
import java.util.Map;

@Controller
@RequestMapping(value = "/message")
public class MessageController {

    @Autowired
    private MessageService messageService;

    @Autowired
    private UserService userService;

    @Autowired
    private HostHolder hostHolder;

    @Autowired
    private SensitiveFilter sensitiveFilter;

    // 私信列表
    @LoginRequired
    @RequestMapping(value = {"","/letter"}, method = RequestMethod.GET)
    public String getLetterList(Model model,
                                @RequestParam(value = "pageIndex", required = false, defaultValue = "1") Integer pageIndex) throws IllegalAccessException {
        UserLogined userLoginedTest = hostHolder.getUser();
        if(userLoginedTest == null){
            throw new IllegalAccessException("非法查看会话列表，当前线程找不到登录用户信息");
        }
        Page page = new Page();
        page.setPageIndex(pageIndex);
        page.setPageSize(10);
        page.setPath("/message/letter");
        page.setDataRows(messageService.checkConversationCount(userLoginedTest.getId()));
        model.addAttribute("page", page);
        Map<String, Object> map = messageService.queryConversationList(userLoginedTest.getId(), page.getPageIndex(), page.getPageSize());
        model.addAttribute("map", map);
        return "/site/letter";
    }

    @LoginRequired
    @RequestMapping(value = "/letter/detail/{idConversation}", method = RequestMethod.GET)
    public String getLetterDetail(Model model,
                                  @PathVariable("idConversation") String idConversation,
                                  @RequestParam(value = "pageIndex", required = false, defaultValue = "1") Integer pageIndex) throws IllegalAccessException, SQLException {
        if(StringUtils.isEmpty(idConversation) || StringUtils.isBlank(idConversation)){
            throw new IllegalAccessException("非法查看会话详情，会话标识为空！");
        }
        Page page = new Page();
        page.setPageIndex(pageIndex);
        page.setPageSize(10);
        page.setPath("/message/letter/detail/" + idConversation);
        page.setDataRows(messageService.checkLetterCount(idConversation));
        model.addAttribute("page", page);
        UserLogined userLoginedTest = hostHolder.getUser();
        if(userLoginedTest == null){
            throw new IllegalAccessException("非法查看会话详情，当前线程找不到登录用户信息");
        }
        model.addAttribute("userLogined", userLoginedTest);
        Map<String, Object> map = messageService.queryLetterList(userLoginedTest.getId(), idConversation, page.getPageIndex(), page.getPageSize());
        model.addAttribute("map", map);
        return "/site/letter-detail";
    }

    @LoginRequired
    @ResponseBody
    @RequestMapping(value = "/letter/add", method = RequestMethod.POST)
    public String addLetter(@RequestParam("usernameReceiver") String usernameReceiver,
                            @RequestParam("content") String content) throws IllegalAccessException, SQLException {
        JsonResultMap jsonResult = new JsonResultMap();
        if(StringUtils.isEmpty(usernameReceiver) || StringUtils.isBlank(usernameReceiver)){
            jsonResult.setCode(500);
            jsonResult.setMsg("接收方用户名不能为空！");
            jsonResult.setCount(0);
            return JSON.toJSONString(jsonResult);
        }
        if(StringUtils.isEmpty(content) || StringUtils.isBlank(content)){
            jsonResult.setCode(500);
            jsonResult.setMsg("私信内容不能为空！");
            jsonResult.setCount(0);
            return JSON.toJSONString(jsonResult);
        }
        Message message = new Message();
        User userTest = userService.checkUserByUsername(usernameReceiver);
        if(userTest == null){
            jsonResult.setCode(500);
            jsonResult.setMsg("接收方用户不存在！");
            jsonResult.setCount(0);
            return JSON.toJSONString(jsonResult);
        }
        message.setIdReceiver(userTest.getId());
        UserLogined userLoginedTest = hostHolder.getUser();
        if(userLoginedTest == null){
            throw new IllegalAccessException("非法发送私信，当前线程找不到登录用户信息");
        }
        message.setIdSender(userLoginedTest.getId());
        if(message.getIdSender() < message.getIdReceiver()){
            message.setIdConversation(message.getIdSender() + "_" + message.getIdReceiver());
        }else{
            message.setIdConversation(message.getIdReceiver() + "_" + message.getIdSender());
        }
        content = HtmlUtils.htmlEscape(content);
        content = sensitiveFilter.filter(content);
        message.setContent(content);
        message.setStatus("unread");
        message.setTimeCreate(new Date());
        Integer num = messageService.increaseLetter(message);
        if(num != 1){
            throw new SQLException("增加私信失败");
        }
        jsonResult.setCode(200);
        jsonResult.setMsg("发送成功！");
        jsonResult.setCount(0);
        return JSON.toJSONString(jsonResult);
    }

    /*删除消息*/
    @LoginRequired
    @ResponseBody
    @RequestMapping(value = "/letter/reduce", method = RequestMethod.POST)
    public String messageReduce(@RequestParam("idMessage") Integer idMessage) throws IllegalAccessException, SQLException {
        if(idMessage == null){
            throw new IllegalAccessException("非法删除消息，消息标识为空");
        }
        JsonResultMap jsonResultMap = new JsonResultMap();
        UserLogined userLogined = hostHolder.getUser();
        if(userLogined == null){
            throw new IllegalAccessException("非法删除消息，当前线程找不到登录用户");
        }
        Message message = messageService.checkById(idMessage);
        if(!userLogined.getId().equals(message.getIdSender())){
            throw new IllegalAccessException("非法删除消息，登录用户只能删除自己发送的消息");
        }
        Integer num = messageService.decreaseById(idMessage);
        if(num != 1){
            throw new SQLException("删除消息失败");
        }
        jsonResultMap.setCode(200);
        jsonResultMap.setMsg("删除成功！");
        return JSON.toJSONString(jsonResultMap);
    }
}
