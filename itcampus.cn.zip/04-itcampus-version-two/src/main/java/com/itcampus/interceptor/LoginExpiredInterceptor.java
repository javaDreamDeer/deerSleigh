package com.itcampus.interceptor;

import com.itcampus.annotation.LoginExpired;
import com.itcampus.annotation.LoginRequired;
import com.itcampus.utils.HostHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.Method;

@Component
public class LoginExpiredInterceptor implements HandlerInterceptor {

    @Autowired
    private HostHolder hostHolder;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        if (handler instanceof HandlerMethod) {
            HandlerMethod handlerMethod = (HandlerMethod) handler;
            Method method = handlerMethod.getMethod();
            LoginExpired loginExpired = method.getAnnotation(LoginExpired.class);
            if (loginExpired != null && hostHolder.getUser() != null) {
                response.sendRedirect(request.getContextPath() + "/main");
                return false;
            }
        }
        return true;
    }
}
