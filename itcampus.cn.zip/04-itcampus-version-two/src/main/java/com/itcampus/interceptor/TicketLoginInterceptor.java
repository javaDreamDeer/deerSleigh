package com.itcampus.interceptor;

import com.itcampus.domain.TicketLogin;
import com.itcampus.domain.User;
import com.itcampus.domain.UserLogined;
import com.itcampus.service.UserService;
import com.itcampus.utils.CookieUtil;
import com.itcampus.utils.HostHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.SQLException;
import java.util.Date;

@Component
public class TicketLoginInterceptor implements HandlerInterceptor {

    @Autowired
    private UserService userService;

    @Autowired
    private HostHolder hostHolder;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // 从cookie中获取凭证
        String username = CookieUtil.getValue(request, "itcampusUsername");
        String ticket = CookieUtil.getValue(request, "itcampusTicket");

        /*System.out.println("itcampusUsername: "+ username);
        System.out.println("itcampusTicket: "+ ticket);*/

        if (username != null && ticket != null) {
            // 查询凭证
            TicketLogin ticketLogin = userService.checkTicketLoginByUsernameTicketStatus(username, ticket, "up");
            // 检查凭证是否有效
            if (ticketLogin != null) {
                if(ticketLogin.getExpired().after(new Date())){
                    // 根据凭证查询用户
                    UserLogined userLogined = userService.checkUserLoginedByUsername(ticketLogin.getUsername());
                    // 在本次请求中持有用户
                    hostHolder.setUser(userLogined);
                }else{
                    Integer num = userService.reviseStatusTicketLoginById(ticketLogin.getId(), "down");
                    if(num != 1){
                        throw new SQLException("系统后台检查到用户当前登录凭证过期，但销毁凭证失败！");
                    }
                }
            }
        }
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        UserLogined userLogined = hostHolder.getUser();
        if (userLogined != null && modelAndView != null) {
            modelAndView.addObject("userLogined", userLogined);
        }
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        hostHolder.clear();
    }
}
