package com.itcampus.config;

import com.itcampus.interceptor.LoginExpiredInterceptor;
import com.itcampus.interceptor.LoginRequiredInterceptor;
import com.itcampus.interceptor.TicketLoginInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.annotation.Resource;

@Configuration
public class InterceptorConfig implements WebMvcConfigurer {

    @Resource
    private TicketLoginInterceptor ticketLoginInterceptor;

    @Resource
    private LoginRequiredInterceptor loginRequiredInterceptor;

    @Resource
    private LoginExpiredInterceptor loginExpiredInterceptor;

    /*
    * 在配置类中指定拦截器的相关配置*/
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        String[] addPathPatterns = {
                "/**"
        };
        String[] excludePathPatterns = {
                "/**/*.css", "/**/*.js", "/**/*.png", "/**/*.jpg", "/**/*.jpeg"
        };
        registry.addInterceptor(ticketLoginInterceptor).addPathPatterns(addPathPatterns).excludePathPatterns(excludePathPatterns);
        registry.addInterceptor(loginRequiredInterceptor).addPathPatterns(addPathPatterns).excludePathPatterns(excludePathPatterns);
        registry.addInterceptor(loginExpiredInterceptor).addPathPatterns(addPathPatterns).excludePathPatterns(excludePathPatterns);
    }
}
