package com.itcampus.event;

import com.alibaba.fastjson.JSON;
import com.itcampus.domain.Notice;
import com.itcampus.service.NoticeService;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class ConsumerEvent {

    private static final Logger logger = LoggerFactory.getLogger(ConsumerEvent.class);

    @Autowired
    private NoticeService noticeService;

    @KafkaListener(topics = {"comment", "reply", "praise", "follow", "goodwill", "illegality"})
    public void handleEvent(ConsumerRecord record){
        if (record == null || record.value() == null) {
            logger.error("通知事件为空");
            return;
        }
        Notice notice = JSON.parseObject(record.value().toString(), Notice.class);
        if (notice == null) {
            logger.error("通知事件格式错误");
            return;
        }
        Integer num = noticeService.increase(notice);
        if(num != 1){
            logger.error("通知事件插入数据库失败");
        }
    }
}
