package com.itcampus.event;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.itcampus.domain.Notice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

@Component
public class ProducerEvent {

    @Autowired
    private KafkaTemplate kafkaTemplate;

    public void triggerEvent(Notice notice){
        kafkaTemplate.send(notice.getTypeEvent(), JSON.toJSONString(notice));
    }
}
