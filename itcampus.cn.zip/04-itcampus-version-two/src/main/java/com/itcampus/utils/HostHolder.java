package com.itcampus.utils;

import com.itcampus.domain.UserLogined;
import org.springframework.stereotype.Component;

/*
* 当前线程暂存用户信息的工具类，用于替换Session方式，配合拦截器跨方法使用暂存对象*/
@Component
public class HostHolder {

    private ThreadLocal<UserLogined> users = new ThreadLocal<>();

    public void setUser(UserLogined userLogined) {
        users.set(userLogined);
    }

    public UserLogined getUser() {
        return users.get();
    }

    public void clear() {
        users.remove();
    }
}
