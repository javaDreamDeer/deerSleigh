package com.itcampus.utils;

public class RedisKeyUtil {

    private static final String SPLIT = ":";
    /*点赞*/
    private static final String PREFIX_ENTITY_PRAISE = "praise:entity";
    private static final String PREFIX_USER_PRAISE = "praise:user";
    /*关注*/
    private static final String PREFIX_FOLLOWEE = "followee";
    private static final String PREFIX_FOLLOWER = "follower";
    /*验证码*/
    private static final String PREFIX_CAPTCHA = "captcha";
    /*登录凭证*/
    /*private static final String PREFIX_TICKET = "ticket:logined";*/
    /*缓存用户信息*/
    private static final String PREFIX_USER = "user";
    /*邮箱验证码*/
    private static final String PREFIX_CAPTCHA_EMAIL = "captcha:email";

    // 某个实体的赞
    // praise:entity:typeEntity:idEntity -> set(idUser)
    public static String getPraiseKeyEntity(String typeEntity, Integer idEntity) {
        return PREFIX_ENTITY_PRAISE + SPLIT + typeEntity + SPLIT + idEntity;
    }

    // 某个用户的赞
    // praise:user:idUser -> int
    public static String getPraiseKeyUser(Integer idUser) {
        return PREFIX_USER_PRAISE + SPLIT + idUser;
    }

    // 某个用户关注的用户或实体
    // followee:idUser:typeEntity -> zset(idEntity,date)
    public static String getFolloweeKey(Integer idUser, String typeEntity) {
        return PREFIX_FOLLOWEE + SPLIT + idUser + SPLIT + typeEntity;
    }

    // 某个用户或实体拥有的粉丝
    // follower:typeEntity:idEntity -> zset(idUser,date)
    public static String getFollowerKey(String typeEntity, Integer idEntity) {
        return PREFIX_FOLLOWER + SPLIT + typeEntity + SPLIT + idEntity;
    }

    // 验证码(涉及登录、注册、找回密码)
    public static String getCaptchaKey(String typeEntity, String owner) {
        return PREFIX_CAPTCHA + SPLIT + typeEntity + SPLIT + owner;
    }

    // 缓存用户数据
    public static String getUserKey(int idUser) {
        return PREFIX_USER + SPLIT + idUser;
    }

    /*缓存邮箱验证码*/
    public static String getCaptchaEmailKey(String email){
        return PREFIX_CAPTCHA_EMAIL + SPLIT + email;
    }
}
