package com.itcampus.utils;

import org.apache.commons.lang3.StringUtils;
import org.springframework.util.DigestUtils;

import java.util.Base64;
import java.util.UUID;

public class SecurityUtil {
    /*
     * 生产随机字符串
     * 随机字符串默认包含'-'，习惯上把'-'给他替换掉*/
    public static String generateUUID(){
        return UUID.randomUUID().toString().replaceAll("-","");
    }
    /*
     * MD5加密
     * 采用的是spring提供的方法DigestUtils
     * 对用户密码进行加密时，采用原密码加随机字符的方式*/
    public static String encryptMD5(String originalText){
        if (StringUtils.isBlank(originalText)){
            return null;
        }
        String encryptText = DigestUtils.md5DigestAsHex(originalText.getBytes());
        return Base64.getEncoder().encodeToString(encryptText.getBytes());
    }
}
