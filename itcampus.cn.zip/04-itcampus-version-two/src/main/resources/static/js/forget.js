$(function(){
    $("form").submit(check_data);
    $("input").focus(clear_error);
});

function check_data() {
    var pwd1 = $("#password").val();
    var pwd2 = $("#confirm-password").val();
    if(pwd1 !== pwd2) {
        $("#confirm-password").removeClass("is-valid");
        $("#confirm-password").addClass("is-invalid");
        return false;
    }else{
        $("#confirm-password").removeClass("is-invalid");
        $("#confirm-password").addClass("is-valid");
        return true;
    }
}

function clear_error() {
    $(this).removeClass("is-invalid");
}

function getCodeVerify(btn) {
    $(btn).addClass("disabled").text("正在发送……");
    var email = $("#email").val().trim();
    $.ajax({
        url: contentPath + "/getCaptchaEmail",
        type: "post",
        data: {
            email: email
        },
        dataType: "json",
        success:function (resp) {
            console.log(resp);
            alert(resp.msg);
            $(btn).removeClass("disabled").text("发送验证");
        }
    });
}