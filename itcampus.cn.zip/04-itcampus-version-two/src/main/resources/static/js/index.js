$(function(){
	$("#publishBtn").click(publish);
});

function publish() {
	$("#publishModal").modal("hide");
	var title = $("#statement-title").val().trim();
	var content = $("#statement-content").val().trim();
	$.ajax({
		url: contentPath + "/statement/add",
		type: "post",
		data: {
			title: title,
			content: content
		},
		dataType: "json",
		success:function (resp) {
			console.log(resp);
			var hintBody = $("#hintBody");
			hintBody.html(resp.msg);
			if(resp.code !== 200){
				hintBody.removeClass("text-success");
				hintBody.addClass("text-danger");
			}else{
				hintBody.removeClass("text-danger");
				hintBody.addClass("text-success");
			}
			$("#sendModal").modal("hide");
			$("#hintModal").modal("show");
			setTimeout(function(){
				$("#hintModal").modal("hide");
				if(resp.code === 200){
					window.location.reload();
				}
			}, 2000);
		}
	});

}