$(function(){
	$("form").submit(check_data);
	$("input").focus(clear_error);
});

function check_data() {
	var pwd1 = $("#password").val();
	var pwd2 = $("#confirm-password").val();
	if(pwd1 !== pwd2) {
		$("#confirm-password").removeClass("is-valid");
		$("#confirm-password").addClass("is-invalid");
		return false;
	}else{
		$("#confirm-password").removeClass("is-invalid");
		$("#confirm-password").addClass("is-valid");
		setTimeout(function () {
			$("#loadingBackdrop").modal("show");
		},1000);
		return true;
	}
}

function clear_error() {
	$(this).removeClass("is-invalid");
}