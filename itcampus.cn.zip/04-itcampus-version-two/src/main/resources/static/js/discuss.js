function praise(btn, typeEntity, idEntity, idUserEntity, statusLogined) {
    if(statusLogined === false){
        alert("您尚未登录！");
    }else{
        $.ajax({
            url: contentPath + "/praise/addOrReduce",
            type: "post",
            data: {
                typeEntity: typeEntity,
                idEntity: idEntity,
                idUserEntity: idUserEntity
            },
            dataType: "json",
            success:function (resp) {
                console.log(resp);
                if(resp.code === 200){
                    $(btn).children("i").text(resp.data.statusPraise);
                    $(btn).children("span").text(resp.data.countPraise);
                    if(resp.data.statusPraise === "已赞"){
                        $(btn).children("i").removeClass("bi-hand-thumbs-up");
                        $(btn).children("i").addClass("bi-hand-thumbs-up-fill");
                        $(btn).children("i").addClass("text-success");
                    }else{
                        $(btn).children("i").removeClass("text-success");
                        $(btn).children("i").removeClass("bi-hand-thumbs-up-fill");
                        $(btn).children("i").addClass("bi-hand-thumbs-up");
                    }
                }
            }
        });
    }
}

var idEntityDelete = null;
var typeEntityDelete = null;
var idEntityIllegality = null;
var typeEntityIllegality = null;

var idEntityExcellent = null;
var idEntityOfficial = null;

var idEntityTopComment = null;
var idEntityTopStatement = null;

$(function () {
    $("#deleteDetermineBtn").on("click", function () {
        $("#deleteModal").modal("hide");
        if(idEntityDelete !== null){
            if(typeEntityDelete === "statement"){
                $.ajax({
                    url: contentPath + "/statement/reduce",
                    type: "post",
                    data: {
                        idEntity: idEntityDelete
                    },
                    dataType: "json",
                    success:function (resp) {
                        console.log(resp);
                        alert(resp.msg);
                        if(resp.code === 200){
                            window.location.href = contentPath + "/main";
                        }
                    }
                });
            }else{
                $.ajax({
                    url: contentPath + "/comment/reduce",
                    type: "post",
                    data: {
                        idEntity: idEntityDelete
                    },
                    dataType: "json",
                    success: function (resp) {
                        console.log(resp);
                        alert(resp.msg);
                        if(resp.code === 200){
                            window.location.reload();
                        }
                    }
                });
            }
        }
    });

    $("#illegalityDetermineBtn").on("click", function () {
        $("#illegalityModal").modal("hide");
        if(idEntityIllegality != null){
            if(typeEntityIllegality === "statement"){
                $.ajax({
                    url: contentPath + "/statement/illegality",
                    type: "post",
                    data: {
                        idEntity: idEntityIllegality
                    },
                    dataType: "json",
                    success:function (resp) {
                        console.log(resp);
                        alert(resp.msg);
                        if(resp.code === 200){
                            window.location.href = contentPath + "/main";
                        }
                    }
                });
            }else{
                $.ajax({
                    url: contentPath + "/comment/illegality",
                    type: "post",
                    data: {
                        idEntity: idEntityIllegality
                    },
                    dataType: "json",
                    success:function (resp) {
                        console.log(resp);
                        alert(resp.msg);
                        if(resp.code === 200){
                            window.location.reload();
                        }
                    }
                });
            }
        }
    });

    $("#excellentDetermineBtn").on("click", function () {
        if(idEntityExcellent !== null){
            $.ajax({
                url: contentPath + "/statement/excellent",
                type: "post",
                data: {
                    idEntity: idEntityExcellent
                },
                dataType: "json",
                success:function (resp) {
                    console.log(resp);
                    alert(resp.msg);
                    if(resp.code === 200){
                        window.location.reload();
                    }
                }
            });
        }
    });

    $("#officialModal").on("click", function () {
        if(idEntityOfficial !== null){
            $.ajax({
                url: contentPath + "/statement/official",
                type: "post",
                data: {
                    idEntity: idEntityOfficial
                },
                dataType: "json",
                success:function (resp) {
                    console.log(resp);
                    alert(resp.msg);
                    if(resp.code === 200){
                        window.location.href = contentPath + "/main";
                    }
                }
            });
        }
    });

    $("#topCommentDetermineBtn").on("click", function () {
        if(idEntityTopComment !== null && idEntityTopStatement !== null){
            $.ajax({
                url: contentPath + "/comment/top",
                type: "post",
                data: {
                    idEntity: idEntityTopComment
                },
                dataType: "json",
                success:function (resp) {
                    console.log(resp);
                    alert(resp.msg);
                    if(resp.code === 200){
                        window.location.href = contentPath + "/statement/detail/"+idEntityTopStatement;
                    }
                }
            });
        }
    })
});

function statementDelete(idStatement) {
    idEntityDelete = idStatement;
    typeEntityDelete = "statement";
    $("#deleteModal").modal("show").find(".modal-body").children("strong").text("确定删除这条发布贴吗？");
}

function commentDelete(idComment) {
    idEntityDelete = idComment;
    typeEntityDelete = "comment";
    $("#deleteModal").modal("show").find(".modal-body").children("strong").text("确定删除这条评论吗？");
}

function replyDelete(idReply) {
    idEntityDelete = idReply;
    typeEntityDelete = "reply";
    $("#deleteModal").modal("show").find(".modal-body").children("strong").text("确定删除这条回复吗？");
}

function statementIllegality(idStatement) {
    idEntityIllegality = idStatement;
    typeEntityIllegality = "statement";
    $("#illegalityModal").modal("show").find(".modal-body").children("strong").text("确定拉黑这条发布贴吗？");
}

function commentIllegality(idComment) {
    idEntityIllegality = idComment;
    typeEntityIllegality = "comment";
    $("#illegalityModal").modal("show").find(".modal-body").children("strong").text("确定拉黑这条评论吗？");
}

function replyIllegality(idReply) {
    idEntityIllegality = idReply;
    typeEntityIllegality = "reply";
    $("#illegalityModal").modal("show").find(".modal-body").children("strong").text("确定拉黑这条回复吗？");
}

function excellent(idStatement) {
    idEntityExcellent = idStatement;
    $("#excellentModal").modal("show").find(".modal-body").children("strong").text("确定设置这条发布贴为精华？");
}

function official(idStatement) {
    idEntityOfficial = idStatement;
    $("#officialModal").modal("show").find(".modal-body").children("strong").text("确定在首页顶置该则发布？");
}

function commentTop(idComment, idStatement) {
    idEntityTopComment = idComment;
    idEntityTopStatement = idStatement;
    $("#topCommentModal").modal("show").find(".modal-body").children("strong").text("确定顶置这条评论吗？");
}