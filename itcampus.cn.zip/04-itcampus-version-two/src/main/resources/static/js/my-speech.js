var btnClose = null;
var typeEntityGlobal = null;

$(function () {
    $("#deleteDetermineBtn").on("click", function () {
        $("#deleteModal").modal("hide");
        if(btnClose !== null){
            var idEntity = $(btnClose).siblings(".idEntityInput").val();
            if(typeEntityGlobal === "statement"){
                $.ajax({
                    url: contentPath + "/statement/reduce",
                    type: "post",
                    data: {
                        idEntity: idEntity
                    },
                    dataType: "json",
                    success:function (resp) {
                        console.log(resp);
                        alert(resp.msg);
                        if(resp.code === 200){
                            window.location.reload();
                        }
                    }
                });
            }else{
                $.ajax({
                    url: contentPath + "/comment/reduce",
                    type: "post",
                    data: {
                        idEntity: idEntity
                    },
                    dataType: "json",
                    success: function (resp) {
                        console.log(resp);
                        alert(resp.msg);
                        if(resp.code === 200){
                            window.location.reload();
                        }
                    }
                });
            }
        }
    })
});

function statementDelete(btn) {
    btnClose = btn;
    typeEntityGlobal = "statement";
    $("#deleteModal").modal("show").find(".modal-body").children("strong").text("确定删除这条发布贴吗？");
}

function commentDelete(btn, typeEntity) {
    btnClose = btn;
    typeEntityGlobal = typeEntity;
    if(typeEntity === "comment"){
        $("#deleteModal").modal("show").find(".modal-body").children("strong").text("确定删除这条评论吗？");
    }else{
        $("#deleteModal").modal("show").find(".modal-body").children("strong").text("确定删除这条回复吗？");
    }
}