//全局变量暂存要关闭的dom对象
var btnClose = null;

$(function(){
	$("#sendBtn").click(send_letter);

	$("#deleteDetermineBtn").on("click", function () {
		$("#deleteModal").modal("hide");
		if(btnClose !== null){
			var idMessage = $(btnClose).siblings(".idMessageInput").val();
			$.ajax({
				url: contentPath + "/message/letter/reduce",
				type: "post",
				data: {
					idMessage: idMessage
				},
				dataType: "json",
				success:function (resp) {
					console.log(resp);
					alert(resp.msg);
					if(resp.code === 200){
						window.location.reload();
					}
				}
			});
		}
	})
});

function send_letter() {
	var usernameReceiver = $("#recipient-name").val().trim();
	var content = $("#message-text").val().trim();
	$.ajax({
		url: contentPath + "/message/letter/add",
		type: "post",
		data: {
			usernameReceiver: usernameReceiver,
			content: content
		},
		dataType: "json",
		success:function (resp) {
			console.log(resp);
			var hintBody = $("#hintBody");
			hintBody.html(resp.msg);
			if(resp.code !== 200){
				hintBody.removeClass("text-success");
				hintBody.addClass("text-danger");
			}else{
				hintBody.removeClass("text-danger");
				hintBody.addClass("text-success");
			}
			$("#sendModal").modal("hide");
			$("#hintModal").modal("show");
			setTimeout(function(){
				$("#hintModal").modal("hide");
				if(resp.code === 200){
					delete_msg();
				}
			}, 2000);
		}
	});
}

function messageDelete(btn) {
	btnClose = btn;
	$("#deleteModal").modal("show").find(".modal-body").children("strong").text("确定删除这条消息吗？");
}

function delete_msg() {
	// TODO 删除数据
	$(btnClose).parents(".media").remove();
}