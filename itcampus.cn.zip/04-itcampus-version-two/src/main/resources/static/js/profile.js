$(function(){
	$(".follow-btn").click(follow);
});

function follow() {
	var btn = this;
	var idEntity = $(btn).siblings(".inputIdEntity").val();
	$.ajax({
		url: contentPath + "/follow/addOrCancel",
		type: "post",
		data: {
			typeEntity: "user",
			idEntity: idEntity
		},
		dataType: "json",
		success:function (resp) {
			console.log(resp);
			$(btn).text(resp.data.statusFollow);
			if(resp.data.statusFollow === "关注TA"){
				$(btn).removeClass("btn-secondary").addClass("btn-info");
			}else{
				$(btn).removeClass("btn-info").addClass("btn-secondary");
			}
		}
	});
	/*if($(btn).hasClass("btn-info")) {
		// 关注TA
		//$(btn).text("已关注").removeClass("btn-info").addClass("btn-secondary");
	} else {
		// 取消关注
		//$(btn).text("关注TA").removeClass("btn-secondary").addClass("btn-info");
	}*/
}