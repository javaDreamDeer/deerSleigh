//全局变量暂存要关闭的dom对象
var btnClose = null;
var btnEmpty = null;
$(function(){
    $("#deleteDetermineBtn").on("click", function () {
        $("#deleteModal").modal("hide");
        if(btnClose !== null){
            var idNotice = $(btnClose).siblings(".idNoticeInput").val();
            $.ajax({
                url: contentPath + "/message/notice/reduce",
                type: "post",
                data: {
                    idNotice: idNotice
                },
                dataType: "json",
                success:function (resp) {
                    console.log(resp);
                    alert(resp.msg);
                    if(resp.code === 200){
                        delete_msg();
                    }
                }
            });
        }
        if(btnEmpty !== null){
            $.ajax({
                url: contentPath + "/message/notice/empty",
                type: "post",
                data: {
                    typeEvent: btnEmpty
                },
                dataType: "json",
                success:function (resp) {
                    console.log(resp);
                    alert(resp.msg);
                    if(resp.code === 200){
                        window.location.reload();
                    }
                }
            });
        }
    })
});

function noticeDelete(btn) {
    btnClose = btn;
    $("#deleteModal").modal("show").find(".modal-body").children("strong").text("确定删除这条通知吗？");
}

function noticeDeleteTotal(typeEvent) {
    /*暂时只提供清空评论通知和点赞通知，这两类通知比较多*/
    btnClose = null;
    btnEmpty = typeEvent;
    if(typeEvent === "comment"){
        $("#deleteModal").modal("show").find(".modal-body").children("strong").text("确定清空所有评论通知吗？");
    }else if(typeEvent === "praise"){
        $("#deleteModal").modal("show").find(".modal-body").children("strong").text("确定清空所有点赞通知吗？");
    }else if(typeEvent === "follow"){
        $("#deleteModal").modal("show").find(".modal-body").children("strong").text("确定清空所有关注通知吗？");
    }else if(typeEvent === "statement"){
        $("#deleteModal").modal("show").find(".modal-body").children("strong").text("确定清空所有提醒通知吗？");
    }else if(typeEvent === "illegality"){
        $("#deleteModal").modal("show").find(".modal-body").children("strong").text("确定清空所有警告通知吗？");
    }
}

function delete_msg() {
    // TODO 删除数据
    $(btnClose).parents(".media").remove();
}